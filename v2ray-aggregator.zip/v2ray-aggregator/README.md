# V2Ray/Xray Telegram Aggregator

A production-grade Cloudflare Worker that monitors a configurable set of Telegram
source channels, extracts newly published V2Ray/Xray configurations (from text and
`.npv` files), enriches them with country metadata, deduplicates, and republishes
them — one at a time, at a configurable interval — to a destination Telegram channel.

It is an **automated aggregation pipeline**, not a manual forwarding tool.

---

## Table of contents

1. [How it works](#how-it-works)
2. [Architecture](#architecture)
3. [Prerequisites](#prerequisites)
4. [Setup (from GitHub Codespace)](#setup-from-github-codespace)
5. [Configuration reference](#configuration-reference)
6. [Admin panel & commands](#admin-panel--commands)
7. [The `.npv` decoding component](#the-npv-decoding-component)
8. [GeoIP country database](#geoip-country-database)
9. [Backups & disaster recovery](#backups--disaster-recovery)
10. [Backfilling historical messages](#backfilling-historical-messages)
11. [Acceptance criteria coverage](#acceptance-criteria-coverage)
12. [Project layout](#project-layout)
13. [Security notes](#security-notes)

---

## How it works

```
Source Telegram channels
        ↓  (webhook push, or 1-min cron poll fallback)
Detect NEW messages only (high-water mark per source)
        ↓
Extract configs  ── text / caption / markdown / code / forwarded ──┐
        ↓                                                            ├→ vmess/vless/trojan/ss/ssr
        └─ .npv attachment  → NPV decoder (isolated) → V2Ray config ─┘
        ↓
Normalize  →  Validate  →  Fingerprint (SHA-256)  →  Deduplicate
        ↓
Resolve hostname → IP (DoH)  →  IP geolocation  →  country code + flag
        ↓
Persistent publishing queue
        ↓
Publish ONE config → wait ≥ 60 s (configurable) → publish next
```

* **Message** is the unit of ingestion; **config** is the unit of publication. A
  source message containing 15 configs produces 15 independent configs.
* Processing state is fully persisted (D1). If the Worker is idle for six hours and
  resumes, it continues from its stored high-water marks and queue — no re-scraping,
  no duplicate publishing.

---

## Architecture

Cloudflare Workers is event-driven (no long-running process), so every "always-on"
concern maps to a Workers-native primitive:

| Concern | Mechanism |
|---|---|
| Persistent state (sources, messages, configs, queue, caches, errors, settings, stats) | **D1** (SQLite) — survives restarts by definition |
| Single-flight publisher + `>=60s` cadence + retry/backoff | **Durable Object** + **Alarm** |
| New-message detection | **Webhook** (primary, real-time) + **Cron** (1-min fallback) |
| IP → country (IPv4 + IPv6) | Bundled **ip2c** database, in-Worker binary search |
| DNS hostname → IP | **DNS-over-HTTPS** (Workers can't open raw DNS sockets) |
| NPV decoding sandbox | **Durable Object** + pure decoder + size/time budget |
| Admin panel | **/admin** HTTP route (password-gated + admin-id-gated) |

### Module layout

```
src/
├── telegram/       client (throttle/retry/flood-wait), formatter, source_listener, admin_commands
├── extraction/     text_extractor, uri_parser, npv/ (decoder + sandbox)
├── config/         model (types), normalizer, validator, fingerprint, build_uri
├── geo/            dns (DoH), ipgeo (range lookup), reserved, geo (orchestrator)
├── queue/          producer, publisher (DO), strategies
├── database/       repository
├── security/       npv_decoder_do (isolated decode sandbox)
├── monitoring/     logging (structured, credential-safe), errors (typed categories)
├── web/            admin_panel
├── pipeline/       processor (ingestion orchestration)
├── types.ts        canonical type definitions
└── main.ts         Worker entrypoint + routing
```

---

## Prerequisites

* A Telegram **bot token** (from [@BotFather](https://t.me/BotFather)).
* The **numeric Telegram user id(s)** of the administrators (get it from
  [@userinfobot](https://t.me/userinfobot)). Authorization never relies on usernames.
* A **destination channel** where the bot can post (`@channel` or a numeric `-100…`
  id; the bot must be an **admin** of that channel unless it owns it).
* Source channels must add the bot as an **admin** (for it to see their posts with
  sufficient privileges; public-channel webhooks generally need the bot added too).
* A Cloudflare account with **Workers Paid** (D1 and Durable Objects are paid
  features) and `wrangler` CLI.

---

## Setup (from GitHub Codespace)

```bash
# 0. (in this repo's GitHub Codespace) install deps
npm install

# 1. Log in to Cloudflare
npx wrangler login

# 2. Create the D1 database, paste the returned database_id into wrangler.jsonc
npx wrangler d1 create v2ray-aggregator-db

# 3. Set secrets
npx wrangler secret put TELEGRAM_BOT_TOKEN
npx wrangler secret put ADMIN_USER_IDS          # comma-separated numeric ids, e.g. "12345,67890"
npx wrangler secret put DESTINATION_CHANNEL     # e.g. "@mydestchannel"
# (ADMIN_PANEL_PASSWORD is set as a var in wrangler.jsonc — change it there for prod)

# 4. Apply the migration (creates all tables + Durable Object classes)
npx wrangler d1 execute v2ray-aggregator-db --remote --file=migrations/0001_init.sql

# 5. (optional) build a GeoIP asset — see "GeoIP country database"

# 6. Deploy
npx wrangler deploy

# 7. Register the webhook (one GET request; uses SET_WEBHOOK_URL or the Worker's own origin)
curl "https://YOUR_WORKER.workers.dev/__webhook_setup"
#  If you set WEBHOOK_SECRET, the same secret is passed to setWebhook as secret_token.

# 8. Open the admin panel at https://YOUR_WORKER.workers.dev/admin and sign in.
```

> **Local development:** copy `.env.example` → `.dev.vars`, run `npx wrangler dev`.
> Note local dev uses a **separate local D1** (see `npm run db:migrate:local`).

---

## Configuration reference

Set via environment variables / secrets (see `.env.example`):

| Variable | Required | Description |
|---|---|---|
| `TELEGRAM_BOT_TOKEN` | ✅ | Bot token from BotFather |
| `ADMIN_USER_IDS` | ✅ | Comma-separated numeric admin ids |
| `DESTINATION_CHANNEL` | ✅ | Destination `@channel` or numeric id |
| `ADMIN_PANEL_PASSWORD` | — | Panel password (default `garigori@123`) |
| `ADMIN_PANEL_PATH` | — | Panel URL path (default `/admin`) |
| `PUBLISH_INTERVAL_MINUTES` | — | Min gap between posts (default `1` = 60 s) |
| `QUEUE_STRATEGY` | — | `chronological` (default) · `source-order` · `country-balanced` · `random` · `newest-first` · `priority-source` |
| `DNS_RESOLVER` | — | DoH endpoint (default Cloudflare) |
| `DNS_TIMEOUT_MS` | — | DNS timeout (default 5000) |
| `NPV_MAX_FILE_BYTES` | — | Max `.npv` size (default 262144) |
| `NPV_DECODE_TIMEOUT_MS` | — | NPV decode budget (default 3000) |

Runtime-tunable settings (also editable in the admin panel / `settings` table):
`publish_interval_minutes`, `queue_strategy`, `paused`, `destination_channel`, `post_template`.

---

## Admin panel & commands

### Web panel (`/admin`)

Two independent gates:

1. **Panel password** — the `ADMIN_PANEL_PASSWORD` (`garigori@123` by default),
   exchanged for an httpOnly session cookie. This gives read access + source
   management.
2. **Admin id** (hard gate on *sending*) — mutating actions that post to the
   destination channel (test messages, publishing) additionally require a numeric
   admin id present in `ADMIN_USER_IDS`. This prevents a password-holder from
   abusing channel-send capability.

The panel shows statistics, sources (add/remove/enable/disable/reset), the publishing
queue, current configuration, recent errors, and a send-test control.

### Telegram bot commands (admin gated by numeric id)

`/start` `/help` `/addsource` `/removesource` `/sources` `/enablesource`
`/disablesource` `/status` `/queue` `/clearqueue` `/config` `/stats`
`/reprocess` `/reset` `/pause` `/resume`

DM the bot with these; only configured admin ids are honored.

---

## The `.npv` decoding component

NapsternetV `.npv` / `.npvt` / `.npv4` files are a proprietary format. They ship in
two real variants:

1. **Unlocked / plaintext export** — the connection parameters (protocol, server,
   port, uuid/password, network, TLS, SNI, etc.) remain present as structured data.
   The decoder **fully reconstructs** a canonical V2Ray/Xray config, which then flows
   through the normal pipeline (normalize → validate → fingerprint→ dedup → country →
   publish).

2. **Encrypted export** — the payload is wrapped in NapsternetV's **white-box
   AES-CTR (NPVT1)** layer (real files show the leading signature bytes
   `DE 91 CE 92 D2 D3 D5 E6`). This is intentionally not generically decryptable: the
   white-box key schedule is version-coupled to the client build and not publicly
   specified.

What the decoder does:

* **Detects** the variant and version from real file signatures.
* **Decodes** the unlocked variant fully.
* **Refuses** the encrypted variant with a typed, version-tagged result — it never
  fabricates a config and never crashes.

Isolation & safety (all enforced):

* Max file size (256 KiB default), decode time budget (3 s default).
* Pure decoder: no filesystem, no child processes, no `eval`, no network, no
  arbitrary execution — it consumes an in-memory `Uint8Array` and returns a parsed
  structure.
* Path-traversal guard on filenames, decompression/archive guards, temp cleanup.
* The decoder is **versioned and isolated** precisely so additional NPV variants
  (including a licensed white-box implementation) can be added as sibling decoders
  without touching the pipeline — see `src/extraction/npv/decoder.ts`.

> **Honest scope:** a licensed white-box (NPVT1) decoder is out of scope for this
> delivery, since no public specification exists. If byte-exact encrypted-NPV
> decoding is required, a vendor-provided module can be dropped into
> `src/extraction/npv/` and registered in the decoder registry.

---

## GeoIP country database

Country is derived from the **resolved IP** (never from the hostname), supporting
both IPv4 and IPv6. Lookups run fully in-Worker via a bundled range database.

* **Recipe:** run `node scripts/build-geoip.mjs`, which downloads the daily-rebuilt
  [ip2c](https://github.com/tn3w/ip2c) `country.csv` (merged from IPFire / DB-IP /
  IP2Location / iptoasn; reserved/unknown → `ZZ`) and emits `dist/geoip-country.json`.
* **Bind** the asset to the Worker (upload to R2/KV or bundle as an asset), and
  expose it on `env.GEOIP`. `src/main.ts` loads it lazily on first lookup.
* Reserved/private/loopback/multicast ranges are always classified `xx` statically,
  regardless of database state.
* IP→country and DNS results are cached in D1; multiple-IP hostnames use a
  deterministic "prefer first IPv4" policy.

When a country can't be determined, posts show **`🌐 xx`** (never an invented country).

---

## Backups & disaster recovery

* All state lives in **D1**. Export a backup with:
  ```bash
  npx wrangler d1 export v2ray-aggregator-db --remote --output backup.sql
  ```
* Restore: re-run `migrations/0001_init.sql` against an empty DB (or `d1 import` the
  backup SQL). Because the schema is idempotent (`CREATE TABLE IF NOT EXISTS` /
  `INSERT OR IGNORE`), replaying is safe.
* The publisher Durable Object uses a **claim token** + `requeue` on tick, so a
  crash mid-publish cannot lose a queue item — stuck `claimed` rows are released on
  the next tick. Publishing is **idempotent** via the `published_messages` ledger
  keyed by config hash, so a timeout-but-accepted send never double-posts.

---

## Backfilling historical messages

By default, adding a source establishes the *current* high-water mark and monitors
only new messages — **no historical spam**.

To backfill:

* **Per source:** `/reset <source-id>` (or the panel "reset" button) sets the
  position to 0, then the next cron/webhook pass sweeps history through the pipeline.
* **Selective:** `/reprocess <source-id> <message-id>` rewinds to just before a
  specific message.

---

## Acceptance criteria coverage

The 29 acceptance criteria in the original specification are implemented as follows
(file → responsibility):

| Criterion | Where |
|---|---|
| Add/remove sources | `database/repository.ts`, `telegram/admin_commands.ts`, `web/admin_panel.ts` |
| Only new messages processed | `telegram/source_listener.ts` (high-water mark) |
| State survives restart | D1 + Durable Object storage |
| Multiple configs per message | `extraction/text_extractor.ts`, `pipeline/processor.ts` |
| vless/vmess/trojan/ss/ssr | `extraction/uri_parser.ts` |
| `.npv` detection | `pipeline/processor.ts` (`isNpv`), `extraction/npv/` |
| `.npv` decode | `extraction/npv/decoder.ts` |
| NPV → pipeline | `pipeline/processor.ts` (`decodeNpvDocument`) |
| Normalize | `config/normalizer.ts` |
| Dedup | `config/fingerprint.ts` + `database/repository.ts` (`insertConfig`) |
| Hostname → IP | `geo/dns.ts` (DoH) |
| IP → country | `geo/ipgeo.ts`, `geo/geo.ts` |
| Country code + flag | `telegram/formatter.ts` |
| Source URL preserved | `pipeline/processor.ts` (`sourceMessageUrl`), `configs`/`queue`/`published_messages` schema |
| Monospace copy-friendly | `telegram/formatter.ts` (`<code>` + HTML escaping) |
| Individual posts | publisher DO |
| ≥60 s interval | publisher DO alarm + `publish_interval_minutes` |
| Queue survives restart | D1 `queue` table |
| Telegram rate limits | `telegram/client.ts` (flood-wait, retry-after, backoff) |
| NPV isolated + limited | `security/npv_decoder_do.ts`, `extraction/npv/sandbox.ts` |
| No credential leakage in logs | `monitoring/logging.ts` (redaction) |
| Admin-only controls | `telegram/admin_commands.ts`, `web/admin_panel.ts` |
| Statistics | `monitoring`+`database` (`statistics` table), `/stats` |
| One error doesn't stop system | `pipeline/processor.ts` (per-config try/catch) |
| Setup/docs/migrations/env/deployment/NPV explainer | this README + `migrations/` + `.env.example` |

---

## Project layout

```
.
├── wrangler.jsonc          # Worker bindings, DOs, cron, vars
├── package.json
├── tsconfig.json
├── .env.example            # environment variable documentation
├── migrations/
│   └── 0001_init.sql        # full D1 schema + initial settings
├── scripts/
│   └── build-geoip.mjs      # build the bundled GeoIP asset
├── src/                     # application source (see "Module layout")
└── test/
    └── unit.test.ts         # 26 pure-function unit tests
```

---

## Security notes

* Secrets only via environment variables / `wrangler secret put`; nothing hardcoded.
* Admin authorization by **numeric Telegram id** (never username).
* All `.npv` input is untrusted: size/time-capped, pure-decoded, no execution.
* No commands or scripts are ever executed from source messages or NPV files.
* Structured logs redact UUIDs, passwords, private keys; full configs are never dumped.
* Admin panel sends require a verified admin id in addition to the panel password.
* D1 queries are fully parameterized; no string-built SQL; no command injection.
