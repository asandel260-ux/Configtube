-- =============================================================================
-- V2Ray/Xray Telegram Aggregator — initial schema
-- Target: Cloudflare D1 (SQLite, WAL not applicable; D1 handles concurrency).
--
-- Design notes:
--  * The "source message" is the unit of ingestion; the "config" is the unit of
--    publication. source_messages rows are written FIRST (idempotently) so a
--    message is never inspected twice even across concurrent workers.
--  * configs.config_hash is a UNIQUE index -> dedup enforced at the DB layer.
--  * queue rows carry an atomic claim token so the Durable Object publisher can
--    dequeue without double-publishing (see enqueue/dequeue logic).
-- =============================================================================

PRAGMA foreign_keys = ON;

-- ---------------------------------------------------------------------------
-- Sources (channels we monitor)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sources (
  source_id                 TEXT PRIMARY KEY,          -- stable uuid
  telegram_channel_id       TEXT NOT NULL,             -- chat id ("@" username or -100…)
  username                  TEXT,                      -- e.g. "mychannel"
  display_name              TEXT,
  enabled                   INTEGER NOT NULL DEFAULT 1, -- 1 = active
  last_processed_message_id INTEGER NOT NULL DEFAULT 0,-- high-water mark
  added_at                  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at                TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_error                TEXT
);

-- ---------------------------------------------------------------------------
-- Source messages (raw ingestion record; enables resume + idempotency)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS source_messages (
  source_message_id INTEGER NOT NULL,
  channel_id        TEXT NOT NULL,                     -- telegram chat id
  message_id        INTEGER NOT NULL,                  -- telegram message id
  timestamp         INTEGER,                           -- unix seconds
  text              TEXT,
  caption           TEXT,
  media             TEXT,                              -- json
  documents         TEXT,                              -- json [{file_id,name,mime,size}]
  raw_update        TEXT,                              -- json, for reprocessing
  processed         INTEGER NOT NULL DEFAULT 1,        -- marked processed even if empty
  configs_found     INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY (channel_id, message_id)
);
CREATE INDEX IF NOT EXISTS idx_sm_channel_ts ON source_messages (channel_id, message_id);

-- ---------------------------------------------------------------------------
-- Configurations (canonical model + fingerprint)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS configs (
  id                 TEXT PRIMARY KEY,                 -- uuid
  config_hash        TEXT NOT NULL UNIQUE,             -- deterministic SHA256
  protocol           TEXT,
  server             TEXT,
  port               INTEGER,
  uuid               TEXT,
  password           TEXT,
  network            TEXT,
  security           TEXT,
  tls                TEXT,
  sni                TEXT,
  host               TEXT,
  path               TEXT,
  service_name       TEXT,
  flow               TEXT,
  public_key         TEXT,
  short_id           TEXT,
  fingerprint        TEXT,
  transport          TEXT,
  country            TEXT,                             -- ISO alpha-2 lowercase (or 'xx')
  normalized         TEXT,                             -- canonical string used for hashing
  source_channel     TEXT,
  source_message_id  INTEGER,
  source_message_url TEXT,
  first_seen         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_seen          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  status             TEXT NOT NULL DEFAULT 'new'       -- new|queued|published|rejected|duplicate
);
CREATE INDEX IF NOT EXISTS idx_configs_server ON configs (server, port);

-- ---------------------------------------------------------------------------
-- Published messages (idempotent publication ledger)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS published_messages (
  publish_id          TEXT PRIMARY KEY,                -- uuid
  config_id           TEXT NOT NULL,
  config_hash         TEXT NOT NULL,
  destination_message_id INTEGER,                      -- Telegram message id after publish
  country             TEXT,
  protocol            TEXT,
  published_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  source_channel      TEXT,
  source_message_url  TEXT
);
CREATE INDEX IF NOT EXISTS idx_pub_hash ON published_messages (config_hash);

-- ---------------------------------------------------------------------------
-- Queue (persistent publishing queue)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS queue (
  queue_id       TEXT PRIMARY KEY,                     -- uuid
  config_id      TEXT NOT NULL,
  config_hash    TEXT NOT NULL,
  protocol       TEXT,
  country        TEXT,
  source_channel TEXT,
  source_message_url TEXT,
  encoded_config TEXT NOT NULL,                        -- the raw config string to publish
  priority       INTEGER NOT NULL DEFAULT 0,
  sort_key       REAL    NOT NULL DEFAULT 0,           -- depends on strategy
  status         TEXT NOT NULL DEFAULT 'pending',      -- pending|claimed|published|failed
  attempts       INTEGER NOT NULL DEFAULT 0,
  claim_token    TEXT,                                 -- tx id of the acting publisher
  next_retry_at  INTEGER,
  destination_message_id_cb INTEGER,                   -- Telegram msg id once published
  enqueued_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_queue_status_sort ON queue (status, sort_key);
CREATE INDEX IF NOT EXISTS idx_queue_claim ON queue (claim_token, status);

-- ---------------------------------------------------------------------------
-- IP / DNS caches
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ip_cache (
  ip        TEXT PRIMARY KEY,
  country   TEXT,
  source    TEXT,
  resolved_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE TABLE IF NOT EXISTS dns_cache (
  hostname      TEXT PRIMARY KEY,                      -- normalized lowercased hostname
  ipv4          TEXT,                                  -- comma-separated
  ipv6          TEXT,
  ttl           INTEGER,
  resolved_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- Processing errors (structured, credential-safe)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS processing_errors (
  error_id   TEXT PRIMARY KEY,
  category   TEXT,                                     -- telegram|dns|geoip|malformed|unsupported|npv|db|download|publish|ratelimit|other
  message    TEXT,                                     -- sanitized, no secrets
  context    TEXT,                                     -- e.g. source_id, message id, hash (no creds)
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_errors_cat ON processing_errors (category);

-- ---------------------------------------------------------------------------
-- Admin users (numeric ids; never rely on username)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS admin_users (
  user_id     INTEGER PRIMARY KEY,
  telegram_username TEXT,
  display_name TEXT,
  is_active   INTEGER NOT NULL DEFAULT 1,
  added_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- Statistics counters (atomic, monotonic)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS statistics (
  stat_key   TEXT PRIMARY KEY,                          -- e.g. messages_scanned
  value      INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- Settings (key/value, admin-configurable)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS settings (
  key        TEXT PRIMARY KEY,
  value      TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- ---------------------------------------------------------------------------
-- Message processing ledger / lock (sources the bot itself reads via getUpdates
-- or webhook; prevents the same source message from being processed twice).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS processing_ledger (
  channel_id   TEXT NOT NULL,
  message_id   INTEGER NOT NULL,
  state        TEXT NOT NULL DEFAULT 'processed',
  updated_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  PRIMARY KEY (channel_id, message_id)
);

-- ---------------------------------------------------------------------------
-- Initial settings
-- ---------------------------------------------------------------------------
INSERT OR IGNORE INTO settings (key, value) VALUES
  ('publish_interval_minutes', '1'),
  ('queue_strategy', 'chronological'),
  ('post_template', 'country_flag_country_code newline mono_config newline attribution'),
  ('paused', '0'),
  ('destination_channel', ''),
  ('last_update_id', '0');
