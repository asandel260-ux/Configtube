// Build a bundled GeoIP asset for the Worker.
//
// Downloads the daily-rebuilt ip2c `country.csv` (IPv4+IPv6, merged from IPFire /
// DB-IP / IP2Location / iptoasn; reserved/unknown → ZZ) and emits a compact JSON
// ranges file that src/geo/ipgeo.ts can load via an asset binding named `GEOIP`.
//
// Usage:
//   node scripts/build-geoip.mjs
//   → writes dist/geoip-country.json (~ a few MB)
//
// Then bind it in wrangler.jsonc as an asset/const, or upload it to R2/KV and
// load lazily. See README "GeoIP database".

import { writeFileSync, mkdirSync } from 'node:fs';

const SRC = 'https://github.com/tn3w/ip2c/releases/latest/download/country.csv';
const OUT_DIR = 'dist';
const OUT_FILE = `${OUT_DIR}/geoip-country.json`;

console.log(`Fetching ${SRC} ...`);
const resp = await fetch(SRC);
if (!resp.ok) throw new Error(`download failed: ${resp.status}`);
const csv = await resp.text();

console.log(`Parsing ${csv.length} bytes ...`);

function ipv4ToBigInt(ip) {
  const p = ip.split('.').map((x) => parseInt(x, 10));
  return (BigInt(p[0]) << 24n) | (BigInt(p[1]) << 16n) | (BigInt(p[2]) << 8n) | BigInt(p[3]);
}
function ipv6ToBigInt(ip) {
  let s = ip.toLowerCase();
  if (s.includes('::')) {
    const [l, r] = s.split('::');
    const lg = l ? l.split(':') : [];
    const rg = r ? r.split(':') : [];
    const missing = 8 - lg.length - rg.length;
    s = [...lg, ...new Array(missing).fill('0'), ...rg].join(':');
  }
  const groups = s.split(':');
  let out = 0n;
  for (const g of groups) out = (out << 16n) | BigInt(parseInt(g || '0', 16));
  return out;
}

const startsByFamily = { 4: [], 6: [] };
let family = null;

for (const rawLine of csv.split(/\r?\n/)) {
  const line = rawLine.trim();
  if (!line) continue;
  if (line === '4' || line === '6') {
    family = line === '4' ? 4 : 6;
    continue;
  }
  if (family === null) continue;
  const parts = line.split(/[,\s]+/).filter(Boolean);
  if (parts.length < 2) continue;
  const ipStr = parts[0];
  const country = parts[parts.length - 1].toLowerCase().trim();
  if (country.length !== 2) continue;
  try {
    const start = family === 4 ? ipv4ToBigInt(ipStr) : ipv6ToBigInt(ipStr);
    startsByFamily[family].push({ start, country });
  } catch {
    /* skip malformed */
  }
}

// Build ranges: each start owns up to (next start - 1), last owns up to family max.
const ranges = [];
const flush = (list, max) => {
  list.sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
  for (let i = 0; i < list.length; i++) {
    const end = i + 1 < list.length ? list[i + 1].start - 1n : max;
    ranges.push({ start: list[i].start.toString(), end: end.toString(), country: list[i].country });
  }
};
flush(startsByFamily[4], (1n << 32n) - 1n);
flush(startsByFamily[6], (1n << 128n) - 1n);

mkdirSync(OUT_DIR, { recursive: true });
writeFileSync(OUT_FILE, JSON.stringify(ranges));
console.log(`Wrote ${ranges.length} ranges to ${OUT_FILE}`);
