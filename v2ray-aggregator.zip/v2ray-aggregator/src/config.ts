import type { Env, QueueStrategy } from './types';

export interface AppConfig {
  botToken: string;
  adminUserIds: number[];
  destinationChannel: string;
  adminPanelPassword: string;
  adminPanelPath: string;
  publishIntervalMinutes: number;
  queueStrategy: QueueStrategy;
  dnsResolver: string;
  dnsTimeoutMs: number;
  npvMaxFileBytes: number;
  npvDecodeTimeoutMs: number;
}

const QUEUE_STRATEGIES: QueueStrategy[] = [
  'chronological',
  'source-order',
  'country-balanced',
  'random',
  'newest-first',
  'priority-source',
];

/** Parse and validate environment configuration. Throws on invalid values. */
export function loadConfig(env: Env, stored?: Partial<Record<string, string>>): AppConfig {
  const botToken = env.TELEGRAM_BOT_TOKEN?.trim();
  if (!botToken) {
    throw new Error('TELEGRAM_BOT_TOKEN is required');
  }

  const destinationChannel = (stored?.destination_channel ?? env.DESTINATION_CHANNEL ?? '').trim();
  if (!destinationChannel) {
    throw new Error('DESTINATION_CHANNEL is required');
  }

  const adminUserIds = parseAdminIds(env.ADMIN_USER_IDS ?? '');
  if (adminUserIds.length === 0) {
    throw new Error('ADMIN_USER_IDS (comma-separated numeric ids) is required');
  }

  const rawInterval = stored?.publish_interval_minutes ?? env.PUBLISH_INTERVAL_MINUTES ?? '1';
  const publishIntervalMinutes = Math.max(1, parseInt(rawInterval, 10) || 1);

  const rawStrategy = (stored?.queue_strategy ?? env.QUEUE_STRATEGY ?? 'chronological') as QueueStrategy;
  const queueStrategy: QueueStrategy = QUEUE_STRATEGIES.includes(rawStrategy) ? rawStrategy : 'chronological';

  return {
    botToken,
    adminUserIds,
    destinationChannel,
    adminPanelPassword: env.ADMIN_PANEL_PASSWORD ?? 'garigori@123',
    adminPanelPath: env.ADMIN_PANEL_PATH ?? '/admin',
    publishIntervalMinutes,
    queueStrategy,
    dnsResolver: env.DNS_RESOLVER ?? 'https://cloudflare-dns.com/dns-query',
    dnsTimeoutMs: parseInt(env.DNS_TIMEOUT_MS ?? '5000', 10) || 5000,
    npvMaxFileBytes: parseInt(env.NPV_MAX_FILE_BYTES ?? '262144', 10) || 262144,
    npvDecodeTimeoutMs: parseInt(env.NPV_DECODE_TIMEOUT_MS ?? '3000', 10) || 3000,
  };
}

function parseAdminIds(raw: string): number[] {
  return raw
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => Number(s))
    .filter((n) => Number.isInteger(n) && n > 0);
}
