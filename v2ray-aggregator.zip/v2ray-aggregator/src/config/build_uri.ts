// Reconstruct a copy-friendly V2Ray/Xray URI from a canonical config.
// Used for configs that did not originate as a URI (e.g. NPV-decoded files),
// so the destination post always shows a standard, importable link.

import type { V2rayConfig } from '../types';

export function buildUri(config: V2rayConfig): string {
  switch (config.protocol) {
    case 'vless': {
      // vless://uuid@host:port?params#tag
      const q = new URLSearchParams();
      if (config.network && config.network !== 'tcp') q.set('type', config.network);
      const sec = config.tls === 'reality' ? 'reality' : config.tls && config.tls !== 'none' ? config.tls : config.security && config.security !== 'none' ? config.security : undefined;
      if (sec) q.set('security', sec);
      if (config.sni) q.set('sni', config.sni);
      if (config.host) q.set('host', config.host);
      if (config.path) q.set('path', config.path);
      if (config.serviceName) q.set('serviceName', config.serviceName);
      if (config.flow) q.set('flow', config.flow);
      if (config.publicKey) q.set('pbk', config.publicKey);
      if (config.shortId) q.set('sid', config.shortId);
      if (config.fingerprint) q.set('fp', config.fingerprint);
      const qs = q.toString();
      return `vless://${config.uuid ?? ''}@${hostPort(config)}${qs ? '?' + qs : ''}${tagSuffix(config)}`;
    }
    case 'trojan': {
      const q = new URLSearchParams();
      const sec = config.tls === 'reality' ? 'reality' : config.tls && config.tls !== 'none' ? config.tls : config.security && config.security !== 'none' ? config.security : undefined;
      if (sec) q.set('security', sec);
      if (config.sni) q.set('sni', config.sni);
      if (config.network && config.network !== 'tcp') q.set('type', config.network);
      const qs = q.toString();
      return `trojan://${config.password ?? ''}@${hostPort(config)}${qs ? '?' + qs : ''}${tagSuffix(config)}`;
    }
    case 'vmess': {
      // vmess://base64(JSON)
      const obj: Record<string, unknown> = {
        v: '2',
        ps: config.tag ?? '',
        add: config.server,
        port: String(config.port ?? 443),
        id: config.uuid ?? '',
        aid: '0',
        net: config.network ?? 'tcp',
        type: config.transport ?? 'none',
        host: config.host ?? '',
        path: config.path ?? '',
        tls: config.tls ?? 'none',
        sni: config.sni ?? '',
      };
      if (config.security) obj.scy = config.security;
      const b64 = btoaLike(JSON.stringify(obj));
      return `vmess://${b64}`;
    }
    case 'ss': {
      // ss://base64(method:password)@host:port#tag
      const mp = btoaLike(`${config.method ?? 'aes-256-gcm'}:${config.password ?? ''}`);
      return `ss://${mp}@${hostPort(config)}${tagSuffix(config)}`;
    }
    case 'ssr': {
      // Not reconstructable losslessly; fall back to canonical.
      return canonicalFallback(config);
    }
    default:
      return canonicalFallback(config);
  }
}

function hostPort(config: V2rayConfig): string {
  const server = config.server.includes(':') && !config.server.startsWith('[') ? `[${config.server}]` : config.server;
  const port = config.port ?? 443;
  return `${server}:${port}`;
}

function tagSuffix(config: V2rayConfig): string {
  return config.tag ? `#${encodeURIComponent(config.tag)}` : '';
}

function canonicalFallback(config: V2rayConfig): string {
  // Minimal lossless fallback: reconstruct a readable form.
  return `${config.protocol}://${hostPort(config)}`;
}

// Base64 (standard alphabet, unpadded is tolerated by most clients; we pad here).
function btoaLike(s: string): string {
  const bytes = new TextEncoder().encode(s);
  let bin = '';
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin);
}
