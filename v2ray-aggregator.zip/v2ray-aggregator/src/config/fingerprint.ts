// Deterministic config fingerprint.
//
// SHA256( normalized_protocol + normalized_server + normalized_port + params )
// → used for exact dedup. The canonical string already embeds every meaningful
// parameter in a stable order, so hashing it is exactly the required scheme.

import { canonicalize } from './normalizer';
import type { V2rayConfig } from '../types';

export async function fingerprint(config: V2rayConfig): Promise<string> {
  const canonical = canonicalize(config);
  const data = new TextEncoder().encode(canonical);
  const digest = await crypto.subtle.digest('SHA-256', data);
  return hex(digest);
}

function hex(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let out = '';
  for (let i = 0; i < bytes.length; i++) out += bytes[i].toString(16).padStart(2, '0');
  return out;
}

/**
 * Distinguish three dedup cases from two hashes + metadata:
 *  - 'exact': same fingerprint
 *  - 'same-endpoint': same server+port, different credentials
 *  - 'different': otherwise
 */
export function dedupClassify(
  a: { hash: string; server: string; port: number | null },
  b: { hash: string; server: string; port: number | null },
): 'exact' | 'same-endpoint' | 'different' {
  if (a.hash === b.hash) return 'exact';
  const sameEndpoint =
    a.server.toLowerCase() === b.server.toLowerCase() && (a.port ?? 0) === (b.port ?? 0);
  return sameEndpoint ? 'same-endpoint' : 'different';
}
