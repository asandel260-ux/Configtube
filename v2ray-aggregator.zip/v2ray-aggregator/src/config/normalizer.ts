// Normalizer: convert a V2rayConfig into a deterministic canonical string
// WITHOUT changing connection behavior. Used for fingerprinting.
//
// Normalizations:
//  * hostname lowercased
//  * default ports normalized (empty -> protocol default)
//  * URL-encoded values decoded (host/path/sni)
//  * parameter ordering made canonical (we already sort by field)
//  * whitespace trimmed
//  * IPv6 canonicalized (expand/compress to canonical form via normalization)
//  * irrelevant formatting differences removed

import type { V2rayConfig } from '../types';

const DEFAULT_PORTS: Record<string, number> = {
  vmess: 443,
  vless: 443,
  trojan: 443,
  ss: 443,
  ssr: 443,
};

/** Normalize a hostname: lowercase, trim, strip URL-encoding. */
export function normalizeHost(host: string): string {
  let h = host.trim().toLowerCase();
  h = decodeSafe(h);
  return h;
}

/** Normalize an IPv6 address to canonical form. */
export function normalizeIpv6(ip: string): string {
  const t = ip.trim().toLowerCase();
  if (!t.includes(':')) return t;
  // Only attempt canonicalization if it looks like a valid address.
  const parts = t.replace(/^\[|\]$/g, '').split('::');
  if (parts.length <= 2) {
    try {
      // Reconstruct canonical compressed form via a simple 8-group expand.
      return canonicalizeIpv6(t);
    } catch {
      return t;
    }
  }
  return t;
}

function canonicalizeIpv6(ip: string): string {
  let s = ip.replace(/^\[|\]$/g, '');
  const hasDc = s.includes('::');
  let groups: string[];
  if (hasDc) {
    const [left, right] = s.split('::');
    const leftG = left ? left.split(':') : [];
    const rightG = right ? right.split(':') : [];
    const missing = 8 - leftG.length - rightG.length;
    groups = [...leftG, ...new Array(missing).fill('0'), ...rightG];
  } else {
    groups = s.split(':');
  }
  const expanded = groups.map((g) => (g === '' ? '0' : g.toLowerCase()).padStart(4, '0'));
  // Re-compress the longest run of zeros for a canonical form.
  let best = expanded.join(':');
  for (let i = 0; i < expanded.length; i++) {
    if (expanded[i] === '0000') {
      let j = i;
      while (j < expanded.length && expanded[j] === '0000') j++;
      if (j - i > 1) {
        const candidate =
          expanded.slice(0, i).join(':') + '::' + expanded.slice(j).join(':');
        if (candidate.length < best.length) best = candidate;
        break;
      }
    }
  }
  return best;
}

function decodeSafe(s: string): string {
  try {
    // Decode percent-encoding on the off-chance hosts are double-encoded.
    const decoded = decodeURIComponent(s);
    return decoded;
  } catch {
    return s;
  }
}

function normString(v: string | undefined): string {
  if (v == null) return '';
  return v.trim();
}

function normPort(v: number | null | undefined, protocol: string): number | null {
  if (v == null) return DEFAULT_PORTS[protocol] ?? null;
  return v;
}

/**
 * Produce the canonical (normalized) string for a config.
 * This exact string is fed to the fingerprint hash.
 */
export function canonicalize(config: V2rayConfig): string {
  const proto = (config.protocol || '').toLowerCase();

  let server = normString(config.server);
  // Distinguish hostname vs IPv6 for normalization.
  if (server.startsWith('[') || (server.includes(':') && !server.includes('.'))) {
    server = normalizeIpv6(server);
  } else {
    server = normalizeHost(server);
  }

  const port = normPort(config.port, proto);

  // Build a stable field list. Only include meaningful differences.
  const fields: [string, string][] = [
    ['protocol', proto],
    ['server', server],
    ['port', port == null ? '' : String(port)],
    ['uuid', normString(config.uuid)],
    ['password', normString(config.password)],
    ['security', normString(config.security).toLowerCase()],
    ['network', normString(config.network).toLowerCase()],
    ['tls', normString(config.tls).toLowerCase()],
    ['sni', serverify(config.sni)],
    ['host', serverify(config.host)],
    ['path', normString(config.path)],
    ['serviceName', normString(config.serviceName)],
    ['flow', normString(config.flow).toLowerCase()],
    ['publicKey', normString(config.publicKey)],
    ['shortId', normString(config.shortId).toLowerCase()],
    ['fingerprint', normString(config.fingerprint).toLowerCase()],
    ['transport', normString(config.transport).toLowerCase()],
    ['method', normString(config.method).toLowerCase()],
  ];

  // Deterministic order (field name ascending) — independent of source ordering.
  fields.sort((a, b) => (a[0] < b[0] ? -1 : a[0] > b[0] ? 1 : 0));

  return fields.filter(([, v]) => v !== '').map(([k, v]) => `${k}=${v}`).join('|');
}

function serverify(v: string | undefined): string {
  if (!v) return '';
  return normalizeHost(v);
}

/** Normalize a config object in place (returns a copy with normalized fields). */
export function normalizeConfig(config: V2rayConfig): V2rayConfig {
  const c: V2rayConfig = { ...config };
  if (typeof c.protocol === 'string') c.protocol = c.protocol.toLowerCase();
  if (typeof c.server === 'string') {
    c.server = c.server.includes(':') && !c.server.startsWith('[') ? normalizeIpv6(c.server) : normalizeHost(c.server);
  }
  if (c.sni) c.sni = normalizeHost(c.sni);
  if (c.host && !c.host.includes(':')) c.host = normalizeHost(c.host);
  return c;
}
