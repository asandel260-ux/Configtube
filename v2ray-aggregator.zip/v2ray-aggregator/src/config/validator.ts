// Validator: reject malformed configs before they reach the queue.

import type { V2rayConfig } from '../types';

const SUPPORTED_PROTOCOLS = new Set(['vmess', 'vless', 'trojan', 'ss', 'ssr']);

export interface ValidationResult {
  valid: boolean;
  reason?: string;
}

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export function validateConfig(config: V2rayConfig): ValidationResult {
  if (!config) return { valid: false, reason: 'empty config' };

  const proto = (config.protocol || '').toLowerCase();
  if (!proto) return { valid: false, reason: 'missing protocol' };
  if (!SUPPORTED_PROTOCOLS.has(proto)) {
    return { valid: false, reason: `unsupported protocol: ${proto}` };
  }

  // Server: must be a non-empty hostname or IP.
  if (!config.server || config.server.trim() === '') {
    return { valid: false, reason: 'missing server' };
  }

  // Port: 1-65535 required for publishable configs (unless protocol has no port concept).
  if (config.port != null && (config.port < 1 || config.port > 65535)) {
    return { valid: false, reason: `invalid port: ${config.port}` };
  }

  // Protocol-specific credential checks.
  switch (proto) {
    case 'vmess':
    case 'vless':
      if (!config.uuid || !UUID_RE.test(config.uuid.trim())) {
        return { valid: false, reason: `invalid or missing uuid for ${proto}` };
      }
      break;
    case 'trojan':
      if (!config.password || config.password.length < 1) {
        return { valid: false, reason: 'trojan requires a password' };
      }
      break;
    case 'ss':
    case 'ssr':
      if (!config.password || config.password.length < 1) {
        return { valid: false, reason: `${proto} requires a password` };
      }
      break;
    default:
      break;
  }

  return { valid: true };
}
