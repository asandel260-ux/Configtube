// Database repository: all D1 access goes through here, parameterized and safe.
// Handles the transactional invariants: idempotent source-message ingestion,
// unique config dedup, atomic queue claim/dequeue.

import type { ConfigAttribution, ProcessedConfig, Source, V2rayConfig } from '../types';

const now = () => new Date().toISOString();

export class Repository {
  constructor(private readonly db: D1Database) {}

  // -------------------------------------------------------------------------
  // Sources
  // -------------------------------------------------------------------------
  async listSources(): Promise<Source[]> {
    const { results } = await this.db
      .prepare('SELECT * FROM sources ORDER BY added_at ASC')
      .all<SourceRow>();
    return (results ?? []).map(mapSource);
  }

  async getSource(sourceId: string): Promise<Source | null> {
    const row = await this.db.prepare('SELECT * FROM sources WHERE source_id = ?').bind(sourceId).first<SourceRow>();
    return row ? mapSource(row) : null;
  }

  async getSourceByChannelId(channelId: string): Promise<Source | null> {
    const row = await this.db
      .prepare('SELECT * FROM sources WHERE telegram_channel_id = ? LIMIT 1')
      .bind(channelId)
      .first<SourceRow>();
    return row ? mapSource(row) : null;
  }

  async addSource(input: {
    source_id: string;
    telegram_channel_id: string;
    username?: string | null;
    display_name?: string | null;
    enabled?: boolean;
  }): Promise<Source> {
    const ts = now();
    await this.db
      .prepare(
        `INSERT INTO sources (source_id, telegram_channel_id, username, display_name, enabled, added_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(source_id) DO UPDATE SET
           telegram_channel_id = excluded.telegram_channel_id,
           username = excluded.username,
           display_name = excluded.display_name,
           enabled = excluded.enabled,
           updated_at = excluded.updated_at`,
      )
      .bind(
        input.source_id,
        input.telegram_channel_id,
        input.username ?? null,
        input.display_name ?? null,
        input.enabled ? 1 : 0,
        ts,
        ts,
      )
      .run();
    return (await this.getSource(input.source_id))!;
  }

  async removeSource(sourceId: string): Promise<boolean> {
    const res = await this.db.prepare('DELETE FROM sources WHERE source_id = ?').bind(sourceId).run();
    return (res.meta?.changes ?? 0) > 0;
  }

  async setSourceEnabled(sourceId: string, enabled: boolean): Promise<boolean> {
    const res = await this.db
      .prepare('UPDATE sources SET enabled = ?, updated_at = ? WHERE source_id = ?')
      .bind(enabled ? 1 : 0, now(), sourceId)
      .run();
    return (res.meta?.changes ?? 0) > 0;
  }

  /** Advance a source's processing position (high-water mark). */
  async updateLastProcessed(sourceId: string, messageId: number): Promise<void> {
    await this.db
      .prepare('UPDATE sources SET last_processed_message_id = ?, updated_at = ? WHERE source_id = ?')
      .bind(messageId, now(), sourceId)
      .run();
  }

  async resetSourcePosition(sourceId: string, messageId = 0): Promise<void> {
    await this.db
      .prepare('UPDATE sources SET last_processed_message_id = ?, updated_at = ?, last_error = NULL WHERE source_id = ?')
      .bind(messageId, now(), sourceId)
      .run();
  }

  async setSourceError(sourceId: string, error: string): Promise<void> {
    await this.db
      .prepare('UPDATE sources SET last_error = ?, updated_at = ? WHERE source_id = ?')
      .bind(error, now(), sourceId)
      .run();
  }

  // -------------------------------------------------------------------------
  // Source messages (idempotent ingestion)
  // -------------------------------------------------------------------------

  /**
   * Atomically claims a source message for processing.
   * Returns 'claimed' if this caller won, 'already' if another worker got it first.
   * The row is inserted (if absent) in the same statement, so concurrent workers
   * cannot both process the same message.
   */
  async claimSourceMessage(channelId: string, messageId: number): Promise<'claimed' | 'already'> {
    const res = await this.db
      .prepare(
        `INSERT OR IGNORE INTO source_messages
           (channel_id, message_id, processed, configs_found)
         VALUES (?, ?, 0, 0)`,
      )
      .bind(channelId, messageId)
      .run();
    if ((res.meta?.changes ?? 0) === 0) {
      // Row already exists -> someone processed it (or is processing).
      return 'already';
    }
    return 'claimed';
  }

  async markSourceMessageProcessed(
    channelId: string,
    messageId: number,
    payload: { text?: string; caption?: string; documents?: string; raw_update?: string; configs_found?: number },
  ): Promise<void> {
    await this.db
      .prepare(
        `UPDATE source_messages
         SET processed = 1, text = COALESCE(?, text), caption = COALESCE(?, caption),
             documents = COALESCE(?, documents), raw_update = COALESCE(?, raw_update),
             configs_found = COALESCE(?, configs_found)
         WHERE channel_id = ? AND message_id = ?`,
      )
      .bind(
        payload.text ?? null,
        payload.caption ?? null,
        payload.documents ?? null,
        payload.raw_update ?? null,
        payload.configs_found ?? null,
        channelId,
        messageId,
      )
      .run();
  }

  // -------------------------------------------------------------------------
  // Configs + dedup
  // -------------------------------------------------------------------------

  /**
   * Persist a config if its hash is not already known.
   * Returns 'new' (inserted) or 'duplicate' (already existed).
   * Uses INSERT ... ON CONFLICT DO NOTHING so the UNIQUE(config_hash) is the
   * single source of truth for dedup.
   */
  async insertConfig(p: ProcessedConfig): Promise<'new' | 'duplicate'> {
    const c = p.config;
    const a = p.attribution;
    const res = await this.db
      .prepare(
        `INSERT INTO configs
           (id, config_hash, protocol, server, port, uuid, password, network, security, tls,
            sni, host, path, service_name, flow, public_key, short_id, fingerprint, transport,
            country, normalized, source_channel, source_message_id, source_message_url, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'new')
         ON CONFLICT(config_hash) DO NOTHING`,
      )
      .bind(
        p.id,
        p.config_hash,
        c.protocol,
        c.server,
        c.port,
        c.uuid ?? null,
        c.password ?? null,
        c.network ?? null,
        c.security ?? null,
        c.tls ?? null,
        c.sni ?? null,
        c.host ?? null,
        c.path ?? null,
        c.serviceName ?? null,
        c.flow ?? null,
        c.publicKey ?? null,
        c.shortId ?? null,
        c.fingerprint ?? null,
        c.transport ?? null,
        p.country,
        p.normalized,
        a.source_channel,
        a.source_message_id,
        a.source_message_url,
      )
      .run();

    if ((res.meta?.changes ?? 0) === 0) {
      // Duplicate: bump last_seen so we can distinguish "same config seen twice".
      await this.db
        .prepare('UPDATE configs SET last_seen = ? WHERE config_hash = ?')
        .bind(now(), p.config_hash)
        .run();
      return 'duplicate';
    }
    return 'new';
  }

  async setConfigCountry(hash: string, country: string): Promise<void> {
    await this.db
      .prepare('UPDATE configs SET country = ? WHERE config_hash = ?')
      .bind(country, hash)
      .run();
  }

  async getConfigByHash(hash: string): Promise<{ id: string; status: string } | null> {
    const row = await this.db
      .prepare('SELECT id, status FROM configs WHERE config_hash = ? LIMIT 1')
      .bind(hash)
      .first<{ id: string; status: string }>();
    return row ?? null;
  }

  // -------------------------------------------------------------------------
  // Queue
  // -------------------------------------------------------------------------

  async enqueue(p: ProcessedConfig, sortKey: number, priority: number): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO queue
           (queue_id, config_id, config_hash, protocol, country, source_channel, source_message_url,
            encoded_config, priority, sort_key, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      )
      .bind(
        crypto.randomUUID(),
        p.id,
        p.config_hash,
        p.config.protocol,
        p.country,
        p.attribution.source_channel,
        p.attribution.source_message_url,
        p.encoded_config,
        priority,
        sortKey,
      )
      .run();
  }

  /** Peek the next pending queue item (without claiming). */
  async peekNextQueueItem(): Promise<QueueItem | null> {
    const row = await this.db
      .prepare(
        `SELECT * FROM queue
         WHERE status = 'pending'
         ORDER BY sort_key ASC, enqueued_at ASC
         LIMIT 1`,
      )
      .first<QueueRow>();
    return row ? mapQueueItem(row) : null;
  }

  /**
   * Atomically claim the next pending item for a given publisher token.
   * Uses a transaction so only one actor can claim a given item.
   */
  async claimNextQueueItem(claimToken: string): Promise<QueueItem | null> {
    const next = await this.peekNextQueueItem();
    if (!next) return null;
    const res = await this.db
      .prepare(
        `UPDATE queue SET status = 'claimed', claim_token = ?, attempts = attempts + 1
         WHERE queue_id = ? AND status = 'pending'`,
      )
      .bind(claimToken, next.queue_id)
      .run();
    if ((res.meta?.changes ?? 0) === 0) {
      // Lost the race — someone else claimed it. Retry once.
      return this.claimNextQueueItem(claimToken);
    }
    return { ...next, status: 'claimed', claim_token: claimToken };
  }

  /** Mark a claimed item as published (idempotent ledger entry is written separately). */
  async completeQueueItem(queueId: string, destinationMessageId: number): Promise<void> {
    await this.db
      .prepare(
        `UPDATE queue SET status = 'published', destination_message_id_cb = ? WHERE queue_id = ?`,
      )
      .bind(destinationMessageId, queueId)
      .run();
  }

  async failQueueItem(queueId: string, delayMs: number): Promise<void> {
    const retryAt = Math.floor(Date.now() / 1000) + Math.ceil(delayMs / 1000);
    await this.db
      .prepare(
        `UPDATE queue SET status = 'pending', claim_token = NULL, next_retry_at = ? WHERE queue_id = ?`,
      )
      .bind(retryAt, queueId)
      .run();
  }

  async requeueClaimed(claimToken: string): Promise<void> {
    // Safety: if a publisher crashed mid-claim, put its stuck items back.
    await this.db
      .prepare(
        `UPDATE queue SET status = 'pending', claim_token = NULL WHERE claim_token = ? AND status = 'claimed'`,
      )
      .bind(claimToken)
      .run();
  }

  async queueLength(): Promise<number> {
    const row = await this.db
      .prepare(`SELECT COUNT(*) AS c FROM queue WHERE status IN ('pending','claimed')`)
      .first<{ c: number }>();
    return row?.c ?? 0;
  }

  async clearQueue(): Promise<number> {
    const res = await this.db.prepare(`DELETE FROM queue WHERE status IN ('pending','claimed')`).run();
    return res.meta?.changes ?? 0;
  }

  async listQueue(limit = 50): Promise<QueueItem[]> {
    const { results } = await this.db
      .prepare(`SELECT * FROM queue WHERE status IN ('pending','claimed') ORDER BY sort_key ASC LIMIT ?`)
      .bind(limit)
      .all<QueueRow>();
    return (results ?? []).map(mapQueueItem);
  }

  // -------------------------------------------------------------------------
  // Publishing ledger (idempotence)
  // -------------------------------------------------------------------------

  /**
   * Insert a publishing record if not already present for this config hash.
   * Returns true if this is a fresh publish (the caller may proceed to send),
   * false if the config was already published (skip to avoid a duplicate post).
   */
  async claimPublish(configHash: string, publishId: string): Promise<'proceed' | 'duplicate'> {
    const res = await this.db
      .prepare(
        `INSERT OR IGNORE INTO published_messages (publish_id, config_id, config_hash)
         VALUES (?, '', ?)`,
      )
      .bind(publishId, configHash)
      .run();
    return (res.meta?.changes ?? 0) > 0 ? 'proceed' : 'duplicate';
  }

  async recordPublished(
    publishId: string,
    configId: string,
    _configHash: string,
    destinationMessageId: number,
    country: string,
    protocol: string,
    sourceChannel: string,
    sourceUrl: string,
  ): Promise<void> {
    await this.db
      .prepare(
        `UPDATE published_messages SET
           config_id = ?, destination_message_id = ?, country = ?, protocol = ?,
           source_channel = ?, source_message_url = ?, published_at = ?
         WHERE publish_id = ?`,
      )
      .bind(configId, destinationMessageId, country, protocol, sourceChannel, sourceUrl, now(), publishId)
      .run();
  }

  async isAlreadyPublished(configHash: string): Promise<boolean> {
    const row = await this.db
      .prepare('SELECT 1 AS x FROM published_messages WHERE config_hash = ? LIMIT 1')
      .bind(configHash)
      .first();
    return !!row;
  }

  // -------------------------------------------------------------------------
  // Caches
  // -------------------------------------------------------------------------

  async getIpCountry(ip: string): Promise<string | null> {
    const row = await this.db.prepare('SELECT country FROM ip_cache WHERE ip = ?').bind(ip).first<{ country: string }>();
    return row?.country ?? null;
  }

  async setIpCountry(ip: string, country: string, source: string): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO ip_cache (ip, country, source) VALUES (?, ?, ?)
         ON CONFLICT(ip) DO UPDATE SET country = excluded.country, resolved_at = excluded.resolved_at`,
      )
      .bind(ip, country, source)
      .run();
  }

  async getDnsCache(hostname: string): Promise<{ ipv4: string; ipv6: string; resolved_at: string } | null> {
    const row = await this.db
      .prepare('SELECT ipv4, ipv6, resolved_at FROM dns_cache WHERE hostname = ?')
      .bind(hostname)
      .first<{ ipv4: string; ipv6: string; resolved_at: string }>();
    return row ?? null;
  }

  async setDnsCache(hostname: string, ipv4: string[], ipv6: string[], ttl: number): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO dns_cache (hostname, ipv4, ipv6, ttl) VALUES (?, ?, ?, ?)
         ON CONFLICT(hostname) DO UPDATE SET ipv4 = excluded.ipv4, ipv6 = excluded.ipv6, ttl = excluded.ttl, resolved_at = excluded.resolved_at`,
      )
      .bind(hostname, ipv4.join(','), ipv6.join(','), ttl)
      .run();
  }

  // -------------------------------------------------------------------------
  // Errors
  // -------------------------------------------------------------------------
  async logError(category: string, message: string, context: Record<string, unknown>): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO processing_errors (error_id, category, message, context)
         VALUES (?, ?, ?, ?)`,
      )
      .bind(crypto.randomUUID(), category, message.slice(0, 512), JSON.stringify(context ?? {}).slice(0, 2048))
      .run();
  }

  // -------------------------------------------------------------------------
  // Statistics
  // -------------------------------------------------------------------------
  async incrementStat(key: string, by = 1): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO statistics (stat_key, value) VALUES (?, ?)
         ON CONFLICT(stat_key) DO UPDATE SET value = value + excluded.value, updated_at = excluded.updated_at`,
      )
      .bind(key, by)
      .run();
  }

  async setStat(key: string, value: number): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO statistics (stat_key, value) VALUES (?, ?)
         ON CONFLICT(stat_key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      )
      .bind(key, value)
      .run();
  }

  async getStats(): Promise<Record<string, number>> {
    const { results } = await this.db.prepare('SELECT stat_key, value FROM statistics').all();
    const out: Record<string, number> = {};
    for (const r of results ?? []) out[(r as { stat_key: string }).stat_key] = (r as { value: number }).value;
    return out;
  }

  // -------------------------------------------------------------------------
  // Settings
  // -------------------------------------------------------------------------
  async getSettings(): Promise<Record<string, string>> {
    const { results } = await this.db.prepare('SELECT key, value FROM settings').all();
    const out: Record<string, string> = {};
    for (const r of results ?? []) out[(r as { key: string }).key] = (r as { value: string }).value;
    return out;
  }

  async getSetting(key: string): Promise<string | null> {
    const row = await this.db.prepare('SELECT value FROM settings WHERE key = ?').bind(key).first<{ value: string }>();
    return row?.value ?? null;
  }

  async setSetting(key: string, value: string): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO settings (key, value) VALUES (?, ?)
         ON CONFLICT(key) DO UPDATE SET value = excluded.value, updated_at = excluded.updated_at`,
      )
      .bind(key, value)
      .run();
  }

  // -------------------------------------------------------------------------
  // Admin users
  // -------------------------------------------------------------------------
  async upsertAdmin(userId: number, username?: string | null, displayName?: string | null): Promise<void> {
    await this.db
      .prepare(
        `INSERT INTO admin_users (user_id, telegram_username, display_name) VALUES (?, ?, ?)
         ON CONFLICT(user_id) DO UPDATE SET telegram_username = excluded.telegram_username`,
      )
      .bind(userId, username ?? null, displayName ?? null)
      .run();
  }

  async isAdmin(userId: number): Promise<boolean> {
    const row = await this.db
      .prepare('SELECT 1 AS x FROM admin_users WHERE user_id = ? AND is_active = 1 LIMIT 1')
      .bind(userId)
      .first();
    return !!row;
  }

  // -------------------------------------------------------------------------
  // Recent errors (for admin panel)
  // -------------------------------------------------------------------------
  async recentErrors(limit = 20): Promise<Array<{ category: string; message: string; context: string; created_at: string }>> {
    const { results } = await this.db
      .prepare('SELECT category, message, context, created_at FROM processing_errors ORDER BY created_at DESC LIMIT ?')
      .bind(limit)
      .all();
    return results as unknown as Array<{ category: string; message: string; context: string; created_at: string }>;
  }
}

// ---------------------------------------------------------------------------
// Row mappers
// ---------------------------------------------------------------------------
interface SourceRow {
  source_id: string;
  telegram_channel_id: string;
  username: string | null;
  display_name: string | null;
  enabled: number;
  last_processed_message_id: number;
  added_at: string;
  updated_at: string;
  last_error: string | null;
}

function mapSource(r: SourceRow): Source {
  return {
    source_id: r.source_id,
    telegram_channel_id: r.telegram_channel_id,
    username: r.username,
    display_name: r.display_name,
    enabled: r.enabled === 1,
    last_processed_message_id: r.last_processed_message_id,
    added_at: r.added_at,
    updated_at: r.updated_at,
    last_error: r.last_error,
  };
}

export interface QueueItem {
  queue_id: string;
  config_id: string;
  config_hash: string;
  protocol: string;
  country: string;
  source_channel: string | null;
  source_message_url: string | null;
  encoded_config: string;
  priority: number;
  sort_key: number;
  status: string;
  attempts: number;
  claim_token: string | null;
  enqueued_at: string;
}

interface QueueRow {
  queue_id: string;
  config_id: string;
  config_hash: string;
  protocol: string;
  country: string;
  source_channel: string | null;
  source_message_url: string | null;
  encoded_config: string;
  priority: number;
  sort_key: number;
  status: string;
  attempts: number;
  claim_token: string | null;
  enqueued_at: string;
  destination_message_id_cb?: number;
}

function mapQueueItem(r: QueueRow): QueueItem {
  return {
    queue_id: r.queue_id,
    config_id: r.config_id,
    config_hash: r.config_hash,
    protocol: r.protocol,
    country: r.country,
    source_channel: r.source_channel,
    source_message_url: r.source_message_url,
    encoded_config: r.encoded_config,
    priority: r.priority,
    sort_key: r.sort_key,
    status: r.status,
    attempts: r.attempts,
    claim_token: r.claim_token,
    enqueued_at: r.enqueued_at,
  };
}

export type { V2rayConfig, ConfigAttribution };
