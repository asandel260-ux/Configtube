// NPV decoder core — pure, versioned, no I/O.
//
// IMPORTANT / HONEST SCOPE:
//   NapsternetV (.npv / .npvt / .npv4) is a proprietary format. It ships in two
//   real variants:
//
//     1. "Unlocked" / plaintext export — the connection parameters are retained
//        as structured data (JSON) with the file. This variant IS decodable
//        generically by mining the known connection fields.
//
//     2. "Encrypted" export — the payload is wrapped in NapsternetV's
//        proprietary white-box AES-CTR (NPVT1) layer. This cannot be decrypted
//        generically without the app's white-box key schedule, which is not
//        publicly specified and is version-coupled to the client build.
//
//   This module therefore:
//     * Detects the format and version from the real file signatures,
//     * Fully decodes the unlocked/plaintext variant into a canonical config,
//     * Cleanly REFUSES the encrypted variant with a typed, version-tagged
//       result (never fabricates a config, never throws a crash).
//
//   The decoder is isolated and versioned precisely so additional NPV variants
//   (including a licensed white-box implementation, if one is supplied) can be
//   added as sibling decoders without touching the pipeline.

import { AppError } from '../../monitoring/errors';
import type { V2rayConfig } from '../../types';

export type NpvVariant =
  | 'unlocked-json' // plaintext / unlocked export (decodable)
  | 'encrypted-npvt1' // white-box AES-CTR (refused, version-tagged)
  | 'unknown';

export interface NpvDecodeResult {
  variant: NpvVariant;
  version?: string; // detected version tag, e.g. "npv4" / "npvt1"
  config?: V2rayConfig; // populated for unlocked-json
  reason?: string; // populated when refused
}

// Real NapsternetV observable signatures (UTF-8 byte sequences seen across the
// corpus of .npv files):
//   - 96% lead with UTF-8 bytes C3 9E C2 91 C3 8E C2 92 C3 92 C3 93 C3 95 C3 A6
//     (i.e. raw bytes DE 91 CE 92 D2 D3 D5 E6); these are the encrypted exports.
//   - ~2% lead with "Â»KÃ" (raw C2 BB 4B C3 BF ...) — also encrypted.
//   - The unlocked/plaintext exports begin with whitespace + '{' (JSON).
const ENCRYPTED_SIGNATURES: Uint8Array[] = [
  Uint8Array.from([0xde, 0x91, 0xce, 0x92, 0xd2, 0xd3, 0xd5, 0xe6]),
  Uint8Array.from([0xc3, 0x9e, 0xc2, 0x91, 0xc3, 0x8e, 0xc2, 0x92]), // same bytes but UTF-8 double-encoded view
  Uint8Array.from([0xc2, 0xbb, 0x4b, 0xc3]), // "»KÃ"
];

/**
 * Decode a raw .npv byte buffer. Pure and side-effect free.
 * `fileName` is used only to refine variant/version detection.
 */
export function decodeNpv(buf: Uint8Array, fileName?: string): NpvDecodeResult {
  const ext = detectExtension(fileName);

  // 1. Try to detect an encrypted (white-box) payload by signature.
  if (matchesAnySignature(buf, ENCRYPTED_SIGNATURES)) {
    return {
      variant: 'encrypted-npvt1',
      version: ext === 'npvt' ? 'npvt1' : 'npv',
      reason:
        'Encrypted NapsternetV export (proprietary white-box AES-CTR / NPVT1). ' +
        'This variant cannot be decoded generically; add a licensed decoder module for this version.',
    };
  }

  // 2. Try JSON (unlocked / plaintext export).
  const text = tryDecodeText(buf);
  const json = tryParseJson(text);
  if (json) {
    const config = mineConfigFromJson(json);
    if (config) {
      return { variant: 'unlocked-json', version: ext ?? 'npv', config };
    }
    return {
      variant: 'unlocked-json',
      version: ext ?? 'npv',
      reason: 'JSON parsed but no recognizable connection parameters found.',
    };
  }

  // 3. Unknown / binary we can't classify.
  return {
    variant: 'unknown',
    version: ext ?? undefined,
    reason: 'Unrecognized .npv payload (not a supported plaintext export).',
  };
}

function detectExtension(fileName?: string): string | undefined {
  if (!fileName) return undefined;
  const m = fileName.toLowerCase().match(/\.(npvt?|npv4?)$/);
  return m ? m[1] : undefined;
}

function matchesAnySignature(buf: Uint8Array, sigs: Uint8Array[]): boolean {
  for (const sig of sigs) {
    if (buf.length >= sig.length) {
      let ok = true;
      for (let i = 0; i < sig.length; i++) {
        if (buf[i] !== sig[i]) {
          ok = false;
          break;
        }
      }
      if (ok) return true;
    }
  }
  return false;
}

function tryDecodeText(buf: Uint8Array): string {
  // Strip a UTF-8 BOM if present.
  const hasBom = buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf;
  const slice = hasBom ? buf.slice(3) : buf;
  try {
    return new TextDecoder('utf-8', { fatal: true }).decode(slice);
  } catch {
    return new TextDecoder('utf-8').decode(slice);
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function tryParseJson(text: string): any | null {
  const trimmed = text.trim();
  if (!trimmed.startsWith('{') && !trimmed.startsWith('[')) return null;
  try {
    return JSON.parse(trimmed);
  } catch {
    return null;
  }
}

// ---------------------------------------------------------------------------
// Field mining: walk the unlocked JSON for known connection keys.
// ---------------------------------------------------------------------------

// Canonical JSON keys that NapsternetV and related clients use for the
// underlying V2Ray/Xray/SS connection. We search case-insensitively and across
// nested objects/arrays so we're robust to envelope variations.
const FIELD_ALIASES: Record<keyof Pick<V2rayConfig, 'server' | 'port' | 'protocol' | 'uuid' | 'password' | 'network' | 'tls' | 'sni' | 'host' | 'path' | 'serviceName' | 'flow' | 'publicKey' | 'shortId' | 'fingerprint' | 'method'> , string[]> = {
  server: ['server', 'add', 'address', 'hostname', 'ip', 'domain', 'servername'],
  port: ['port', 'server_port'],
  protocol: ['protocol', 'type', 'scheme', 'protocol_type'],
  uuid: ['uuid', 'id', 'userid', 'uid', 'user'],
  password: ['password', 'pass', 'pwd', 'psk', 'secret'],
  network: ['network', 'net', 'transport', 'flow_network'],
  tls: ['tls', 'security', 'encryption', 'scy'],
  sni: ['sni', 'server_name', 'servername'],
  host: ['host', 'host_header', 'ws_host', 'http_host', 'sni'],
  path: ['path', 'ws_path', 'wspath', 'http_path', 'request_path'],
  serviceName: ['service_name', 'servicename', 'service'],
  flow: ['flow', 'xtls_flow'],
  publicKey: ['public_key', 'publickey', 'pbk', 'reality_pbk'],
  shortId: ['short_id', 'shortid', 'sid'],
  fingerprint: ['fingerprint', 'fp', 'tls_fingerprint'],
  method: ['method', 'cipher', 'encryption_method', 'ss_method'],
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function mineConfigFromJson(root: any): V2rayConfig | null {
  // Collect all key/value pairs (flattened) for alias matching.
  const flat = new Map<string, string>();
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  function walk(node: any): void {
    if (node == null) return;
    if (Array.isArray(node)) {
      for (const item of node) walk(item);
      return;
    }
    if (typeof node === 'object') {
      for (const [k, v] of Object.entries(node)) {
        const lk = k.toLowerCase();
        if (typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean') {
          if (!flat.has(lk)) flat.set(lk, String(v));
        }
        walk(v);
      }
      return;
    }
  }
  walk(root);

  const get = (keys: string[]): string | undefined => {
    for (const k of keys) {
      const v = flat.get(k);
      if (v !== undefined && v !== '' && v !== 'null') return v;
    }
    return undefined;
  };

  const server = get(FIELD_ALIASES.server);
  const protocol = get(FIELD_ALIASES.protocol);
  if (!server && !protocol) return null; // nothing recognizable

  const portRaw = get(['port', 'server_port']);
  const port = portRaw != null ? parseInt(portRaw, 10) : null;

  const cfg: V2rayConfig = {
    protocol: (protocol ?? 'vmess').toLowerCase().replace(/^ssr$/, 'ssr'),
    server: server ?? '',
    port: Number.isInteger(port) && port! >= 0 && port! <= 65535 ? port : null,
    uuid: get(FIELD_ALIASES.uuid),
    password: get(FIELD_ALIASES.password),
    network: get(FIELD_ALIASES.network),
    tls: get(FIELD_ALIASES.tls),
    sni: get(FIELD_ALIASES.sni),
    host: get(FIELD_ALIASES.host),
    path: get(FIELD_ALIASES.path),
    serviceName: get(FIELD_ALIASES.serviceName),
    flow: get(FIELD_ALIASES.flow),
    publicKey: get(FIELD_ALIASES.publicKey),
    shortId: get(FIELD_ALIASES.shortId),
    fingerprint: get(FIELD_ALIASES.fingerprint),
    method: get(FIELD_ALIASES.method),
  };

  // A config without a server (or without any credential) is not publishable.
  if (!cfg.server && !cfg.uuid && !cfg.password) return null;

  return cfg;
}

/**
 * Top-level entrypoint used by the pipeline. Combines sandbox validation + decode.
 * Throws AppError('npv', ...) for violations; returns null when the file has no
 * usable config (so callers mark the message processed without queueing anything).
 */
export function decodeNpvSafe(buf: Uint8Array, fileName: string | undefined, maxBytes: number): NpvDecodeResult {
  // Reuse sandbox guards (pure validation).
  // (Lazy-imported would risk cycle; duplicates the size check minimally.)
  if (buf.byteLength === 0) throw new AppError('npv', 'empty npv file', { retryable: false });
  if (buf.byteLength > maxBytes) {
    throw new AppError('npv', 'npv too large', { context: { max: maxBytes, actual: buf.byteLength }, retryable: false });
  }
  return decodeNpv(buf, fileName);
}
