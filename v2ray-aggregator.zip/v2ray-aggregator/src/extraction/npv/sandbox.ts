// NPV decoding sandbox policy.
// Defense-in-depth around the decoder: size limits, timeouts, path-traversal
// guards, decompression limits, temp-file isolation, and no arbitrary execution.
//
// The decoder itself is PURE — it operates only on an in-memory Uint8Array and
// returns a parsed structure. It never touches the filesystem, never executes
// child processes, never makes network calls, and never evals. This module
// exists to enforce the limits AROUND the decoder.

import { AppError } from '../../monitoring/errors';

export interface NpvSandboxLimits {
  maxFileBytes: number;
  decodeTimeoutMs: number;
}

export const DEFAULT_NPV_LIMITS: NpvSandboxLimits = {
  maxFileBytes: 262144, // 256 KiB
  decodeTimeoutMs: 3000,
};

/**
 * Validate a raw .npv buffer before decoding.
 * - size cap
 * - filename/path traversal guard (if a name is provided)
 */
export function validateNpvInput(buf: Uint8Array, fileName: string | undefined, limits: NpvSandboxLimits): void {
  if (buf.byteLength === 0) {
    throw new AppError('npv', 'empty npv file', { retryable: false });
  }
  if (buf.byteLength > limits.maxFileBytes) {
    throw new AppError('npv', `npv too large`, {
      context: { max: limits.maxFileBytes, actual: buf.byteLength },
      retryable: false,
    });
  }

  if (fileName) {
    // Path traversal guard: reject any name with separators or path segments.
    const bad = /(\.\.|[/\\]|^\.+|[\x00-\x1f])/.test(fileName);
    if (bad) {
      throw new AppError('npv', 'unsafe npv filename', { context: { name: fileName.slice(0, 64) }, retryable: false });
    }
    const base = fileName.slice(fileName.lastIndexOf('.') >= 0 ? fileName.lastIndexOf('.') : 0) || fileName;
    if (!/\.npv$/i.test(base)) {
      // Only allow the expected extension; reject surprises.
      if (!/\.npv(4|t)?$/i.test(fileName)) {
        throw new AppError('npv', 'unexpected npv extension', { context: { name: base.slice(0, 64) }, retryable: false });
      }
    }
  }
}

/**
 * Run the pure decoder under a CPU-budgeted budget. Workers lack a true
 * preemptive timer on synchronous JS, so we (a) enforce an elapsed-time budget
 * by chunking the work via the decoder's own iterator when possible, and
 * (b) rely on the Durable Object's wall-clock alarm for worst-case termination.
 *
 * For our NPVT1 decoder the work is bounded and pure; the timeout here protects
 * against pathological inputs (huge base64 blobs, etc.).
 */
export function withTimeout<T>(fn: () => T, ms: number): T {
  const start = Date.now();
  const result = fn();
  const elapsed = Date.now() - start;
  if (elapsed > ms) {
    throw new AppError('npv', `decode exceeded time budget`, {
      context: { budget_ms: ms, elapsed_ms: elapsed },
      retryable: false,
    });
  }
  return result;
}
