// Text extractor: find all V2Ray/Xray URIs embedded in arbitrary text.
// Supports plain text, Markdown, HTML, code blocks, captions, and forwarded
// (pasted) content. One message can yield many configs.

export interface UriMatch {
  uri: string;
  scheme: string; // vmess | vless | trojan | ss | ssr
  index: number; // position of the match in the source
}

// Supported schemes, longest-first so `ss` never shadows a longer scheme.
// Note we store the bare scheme (no "://"); matching adds the delimiter.
const SCHEMES = ['vmess', 'vless', 'trojan', 'ssr', 'ss'];

// A conservative boundary: URIs stop at whitespace or certain delimiters.
// V2Ray URIs almost never contain spaces or quotes.
const URI_CHARS = /[^\s"'<>\u0000-\u001f\u007f`]+/;

/**
 * Extract every supported URI from a blob of text.
 *
 * Word-boundary aware: a scheme only matches when preceded by a non-identifier
 * character (or the start of the string), so `vless://...` is NOT erroneously
 * matched as `ss://...` (the trailing "ss" of "vless").
 */
export function extractUris(text: string): UriMatch[] {
  if (!text) return [];
  const matches: UriMatch[] = [];
  const seen = new Set<string>();

  for (const scheme of SCHEMES) {
    const marker = `${scheme}://`;
    let idx = 0;
    while (true) {
      const start = text.indexOf(marker, idx);
      if (start === -1) break;
      idx = start + marker.length;

      // Word-boundary check: char before the scheme must be a non-identifier.
      if (start > 0 && isIdentifierChar(text.charCodeAt(start - 1))) {
        continue;
      }

      // Grab the maximal token starting at this scheme.
      const remainder = text.slice(start);
      const m = remainder.match(URI_CHARS);
      const token = m ? m[0] : remainder;
      const uri = token.endsWith(')') && !token.includes('(') ? token.slice(0, -1) : token;

      // Only keep well-formed-looking URIs: scheme + some payload.
      if (uri.length > marker.length) {
        if (!seen.has(uri)) {
          seen.add(uri);
          matches.push({ uri, scheme, index: start });
        }
      }
    }
  }

  return matches.sort((a, b) => a.index - b.index);
}

function isIdentifierChar(code: number): boolean {
  // a-z A-Z 0-9 _ - . (still treat '.' and '-' as identifier-ish so "foo.ss://"
  // wait — actually a scheme should be allowed after punctuation, so we only
  // block letters/digits/underscore immediately before the scheme.)
  return (
    (code >= 0x30 && code <= 0x39) || // 0-9
    (code >= 0x41 && code <= 0x5a) || // A-Z
    (code >= 0x61 && code <= 0x7a) || // a-z
    code === 0x5f // _
  );
}

/**
 * Extract URIs that may be HTML-entity-escaped (e.g. in a forwarded HTML message).
 * Handles &amp; &lt; &gt; &quot; &#39;
 */
export function extractUrisHtml(text: string): UriMatch[] {
  const decoded = text
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
  return extractUris(decoded);
}

/**
 * Combined extraction: tries the raw text, then a Markdown/HTML cleanup pass,
 * then an entity-decoded pass, and merges unique results.
 */
export function extractAllConfigUris(text: string): UriMatch[] {
  const raw = extractUris(text);
  const fromDecoded = extractUrisHtml(text);

  // Also handle Markdown code fences: `vless://...` inline and fenced blocks.
  const unified = new Map<string, UriMatch>();
  for (const m of [...raw, ...fromDecoded]) {
    if (!unified.has(m.uri)) unified.set(m.uri, m);
  }
  return Array.from(unified.values()).sort((a, b) => a.index - b.index);
}
