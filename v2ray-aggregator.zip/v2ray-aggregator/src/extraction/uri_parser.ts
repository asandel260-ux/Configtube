// URI parsers for the supported V2Ray/Xray config formats.
// Extensible: register a new parser by adding it to PARSERS.

import type { V2rayConfig } from '../types';
import { AppError } from '../monitoring/errors';

export interface UriParser {
  scheme: string;
  parse(uri: string): V2rayConfig;
}

function b64decode(s: string): string {
  const norm = s.replace(/-/g, '+').replace(/_/g, '/');
  const padded = norm + '='.repeat((4 - (norm.length % 4)) % 4);
  try {
    return new TextDecoder().decode(Uint8Array.from(atob(padded), (c) => c.charCodeAt(0)));
  } catch {
    // Some clients emit unpadded base64; retry with URL-safe decode via atob fallback.
    try {
      return atob(padded);
    } catch {
      throw new AppError('malformed', 'invalid base64 in config', { retryable: false });
    }
  }
}

// ---------------------------------------------------------------------------
// vmess://  → base64(JSON{ v, ps, add, port, id, aid, scy, net, type, host, path, tls, sni, ... })
// ---------------------------------------------------------------------------
const vmessParser: UriParser = {
  scheme: 'vmess',
  parse(uri: string): V2rayConfig {
    const body = uri.slice('vmess://'.length);
    const jsonStr = b64decode(body);
    const o = JSON.parse(jsonStr) as Record<string, unknown>;
    const cfg: V2rayConfig = {
      protocol: 'vmess',
      server: String(o.add ?? ''),
      port: toPort(o.port),
      uuid: o.id != null ? String(o.id) : undefined,
      security: o.scy != null ? String(o.scy) : (o.security != null ? String(o.security) : undefined),
      network: o.net != null ? String(o.net) : 'tcp',
      tls: o.tls != null ? String(o.tls) : 'none',
      sni: o.sni != null ? String(o.sni) : undefined,
      host: o.host != null ? String(o.host) : undefined,
      path: o.path != null ? String(o.path) : undefined,
      fingerprint: o.fp != null ? String(o.fp) : undefined,
      transport: o.type != null ? String(o.type) : undefined,
      tag: o.ps != null ? String(o.ps) : undefined,
      raw: uri,
    };
    return cfg;
  },
};

// ---------------------------------------------------------------------------
// vless://uuid@host:port?type=&security=&encryption=&headerType=&host=&path=&...
// trojan://password@host:port?security=&sni=&type=&host=&path=#name
// ---------------------------------------------------------------------------
function parseWatchURI(scheme: 'vless' | 'trojan', uri: string, _credKey: 'uuid' | 'password'): V2rayConfig {
  const rest = uri.slice(`${scheme}://`.length);
  const hashIdx = rest.indexOf('#');
  const tag = hashIdx >= 0 ? rest.slice(hashIdx + 1) : undefined;
  const main = hashIdx >= 0 ? rest.slice(0, hashIdx) : rest;
  const queryIdx = main.indexOf('?');
  const userinfoHostPort = queryIdx >= 0 ? main.slice(0, queryIdx) : main;
  const query = queryIdx >= 0 ? main.slice(queryIdx + 1) : '';

  // userinfo@host:port
  const atIdx = userinfoHostPort.lastIndexOf('@');
  if (atIdx < 0) throw new AppError('malformed', `${scheme} uri missing '@'`, { retryable: false });
  const cred = userinfoHostPort.slice(0, atIdx);
  const hostPort = userinfoHostPort.slice(atIdx + 1);
  const { host, port } = splitHostPort(hostPort);

  const q = new URLSearchParams(query);
  const cfg: V2rayConfig = {
    protocol: scheme,
    server: host,
    port,
    network: q.get('type') ?? 'tcp',
    security: q.get('security') ?? 'none',
    tls: queryTls(q),
    sni: q.get('sni') ?? undefined,
    host: q.get('host') ?? undefined,
    path: q.get('path') ?? undefined,
    serviceName: q.get('serviceName') ?? undefined,
    flow: q.get('flow') ?? undefined,
    publicKey: q.get('pbk') ?? undefined,
    shortId: q.get('sid') ?? undefined,
    fingerprint: q.get('fp') ?? undefined,
    tag: tag ? decodeURIComponentSafe(tag) : undefined,
    raw: uri,
  };
  if (scheme === 'vless') cfg.uuid = cred;
  else cfg.password = cred;
  return cfg;
}

const vlessParser: UriParser = { scheme: 'vless', parse: (u) => parseWatchURI('vless', u, 'uuid') };
const trojanParser: UriParser = { scheme: 'trojan', parse: (u) => parseWatchURI('trojan', u, 'password') };

function queryTls(q: URLSearchParams): string {
  // vless/trojan sometimes use `security=tls|reality` rather than a `tls` param.
  const sec = q.get('security') ?? 'none';
  if (sec === 'reality' || sec === 'tls') return sec;
  const tls = q.get('tls');
  return tls ?? 'none';
}

// ---------------------------------------------------------------------------
// ss://  → legacy (base64[method:password]@host:port) or SIP002
//          (base64(method:password)@host:port#tag, or method:pass@host:port)
// ---------------------------------------------------------------------------
const ssParser: UriParser = {
  scheme: 'ss',
  parse(uri: string): V2rayConfig {
    let body = uri.slice('ss://'.length);
    const tagIdx = body.lastIndexOf('#');
    let tag: string | undefined;
    if (tagIdx >= 0) {
      tag = body.slice(tagIdx + 1);
      body = body.slice(0, tagIdx);
    }

    const atIdx = body.lastIndexOf('@');
    let method: string;
    let password: string;
    let hostPort: string;

    if (atIdx >= 0) {
      // SIP002: method:password@host:port  (method:password may be base64 or plain)
      const before = body.slice(0, atIdx);
      hostPort = body.slice(atIdx + 1);
      const [decodedMethod, ...pwParts] = tryDecodeMethodPassword(before);
      method = decodedMethod;
      password = pwParts.join(':');
    } else {
      // Legacy: entire body is base64(method:password@host:port)
      const decoded = b64decode(body);
      const innerAt = decoded.lastIndexOf('@');
      if (innerAt < 0) throw new AppError('malformed', 'legacy ss uri missing @', { retryable: false });
      const mp = decoded.slice(0, innerAt);
      hostPort = decoded.slice(innerAt + 1);
      const [m, ...pw] = mp.split(':');
      method = m;
      password = pw.join(':');
    }

    const { host, port } = splitHostPort(hostPort);
    return {
      protocol: 'ss',
      server: host,
      port,
      method,
      password,
      tag: tag ? decodeURIComponentSafe(tag) : undefined,
      raw: uri,
    };
  },
};

function tryDecodeMethodPassword(before: string): [string, string] {
  // Try base64 first (SIP002), fall back to plain.
  try {
    const d = b64decode(before);
    if (d.includes(':')) return [d.split(':')[0], d.split(':').slice(1).join(':')];
  } catch {
    /* fall through to plain */
  }
  const idx = before.indexOf(':');
  if (idx < 0) throw new AppError('malformed', 'ss method:password malformed', { retryable: false });
  return [before.slice(0, idx), before.slice(idx + 1)];
}

// ---------------------------------------------------------------------------
// ssr://  → base64(host:port:protocol:method:obfs:base64(password)/?params...)
// ---------------------------------------------------------------------------
const ssrParser: UriParser = {
  scheme: 'ssr',
  parse(uri: string): V2rayConfig {
    const body = uri.slice('ssr://'.length);
    const decoded = b64decode(body);
    // SSR historically uses base64url with a trailing '='; normalize.
    const qIdx = decoded.indexOf('/?');
    const main = qIdx >= 0 ? decoded.slice(0, qIdx) : decoded;
    const parts = main.split(':');
    if (parts.length < 6) throw new AppError('malformed', 'ssr uri has fewer than 6 fields', { retryable: false });
    const [server, portStr, protocol, method, obfs, passB64] = parts;
    let password = passB64;
    try {
      password = b64decode(passB64);
    } catch {
      /* keep raw */
    }
    return {
      protocol: 'ssr',
      server,
      port: toPort(portStr),
      security: protocol !== 'origin' ? protocol : undefined,
      method,
      password,
      transport: obfs !== 'plain' ? obfs : undefined,
      raw: uri,
    };
  },
};

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------
export const URI_PARSERS: Record<string, UriParser> = {
  vmess: vmessParser,
  vless: vlessParser,
  trojan: trojanParser,
  ss: ssParser,
  ssr: ssrParser,
};

/** Parse a single URI (by scheme) into a canonical V2rayConfig. */
export function parseUri(uri: string): V2rayConfig {
  for (const scheme of Object.keys(URI_PARSERS)) {
    if (uri.startsWith(`${scheme}://`)) {
      return URI_PARSERS[scheme].parse(uri);
    }
  }
  throw new AppError('unsupported', 'no parser for URI scheme', { retryable: false });
}

function splitHostPort(hostPort: string): { host: string; port: number | null } {
  // Handle IPv6 literals like [::1]:443
  if (hostPort.startsWith('[')) {
    const end = hostPort.indexOf(']');
    if (end >= 0) {
      const host = hostPort.slice(1, end);
      const rest = hostPort.slice(end + 1);
      const port = rest.startsWith(':') ? toPort(rest.slice(1)) : null;
      return { host, port };
    }
  }
  const idx = hostPort.lastIndexOf(':');
  if (idx < 0) return { host: hostPort, port: null };
  const host = hostPort.slice(0, idx);
  const port = toPort(hostPort.slice(idx + 1));
  return { host, port };
}

function toPort(v: unknown): number | null {
  if (v == null) return null;
  const n = typeof v === 'string' ? parseInt(v, 10) : Number(v);
  return Number.isInteger(n) && n >= 0 && n <= 65535 ? n : null;
}

function decodeURIComponentSafe(s: string): string {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}
