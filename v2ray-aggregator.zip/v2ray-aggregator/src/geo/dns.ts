// DNS resolution via DNS-over-HTTPS (works inside Cloudflare Workers, which
// block raw UDP/TCP DNS sockets but allow outbound HTTPS fetch).

import { AppError } from '../monitoring/errors';
import { createLogger } from '../monitoring/logging';

const log = createLogger('geo:dns');

export interface DnsResult {
  ipv4: string[];
  ipv6: string[];
  ttl: number;
}

const IPV4_RE = /^(?:\d{1,3}\.){3}\d{1,3}$/;
const IPV6_RE = /^[0-9a-f:]+$/i;

export function isIpLiteral(host: string): boolean {
  return IPV4_RE.test(host) || (host.includes(':') && IPV6_RE.test(host.replace(/^\[|\]$/g, '')));
}

interface DoHResponse {
  Status?: number;
  Answer?: Array<{ name: string; type: number; TTL: number; data: string }>;
}

/**
 * Resolve a hostname (or return an IP literal as-is) into IPv4/IPv6 lists.
 * Deterministic ordering: sort within each family.
 */
export async function resolveHost(host: string, resolver: string, timeoutMs: number): Promise<DnsResult> {
  const h = host.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (isIpLiteral(h)) {
    return h.includes(':') ? { ipv4: [], ipv6: [canonicalIp(h)], ttl: 3600 } : { ipv4: [h], ipv6: [], ttl: 3600 };
  }

  const url = `${resolver}?name=${encodeURIComponent(h)}&type=A`;
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const resp = await fetch(url, {
      headers: { accept: 'application/dns-json' },
      signal: ctrl.signal,
    });
    if (!resp.ok) {
      throw new AppError('dns', `DoH resolver returned ${resp.status}`, {
        context: { host: h },
        retryable: true,
      });
    }
    const json = (await resp.json()) as DoHResponse;
    const ipv4 = (json.Answer ?? [])
      .filter((a) => a.type === 1)
      .map((a) => a.data)
      .filter(isIpLiteral)
      .sort();

    // Second query for AAAA.
    let ipv6: string[] = [];
    try {
      const url6 = `${resolver}?name=${encodeURIComponent(h)}&type=AAAA`;
      const resp6 = await fetch(url6, { headers: { accept: 'application/dns-json' }, signal: ctrl.signal });
      if (resp6.ok) {
        const json6 = (await resp6.json()) as DoHResponse;
        ipv6 = (json6.Answer ?? [])
          .filter((a) => a.type === 28)
          .map((a) => a.data)
          .sort()
          .map(canonicalIp);
      }
    } catch {
      // AAAA is optional; ignore failure.
    }

    if (ipv4.length === 0 && ipv6.length === 0) {
      throw new AppError('dns', `no A/AAAA records for host`, { context: { host: h }, retryable: true });
    }

    const ttl = Math.min(...(json.Answer ?? []).filter((a) => a.TTL > 0).map((a) => a.TTL), 86400);
    return { ipv4, ipv6, ttl: Number.isFinite(ttl) ? ttl : 3600 };
  } catch (e) {
    if ((e as AppError).name === 'AppError') throw e;
    throw new AppError('dns', 'DNS resolution failed', { context: { host: h }, retryable: true, cause: e });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Deterministic policy for choosing a representative IP when a hostname resolves
 * to multiple addresses: prefer IPv4, then sort and pick the first. This makes
 * country attribution stable across runs.
 */
export function chooseRepresentativeIp(ipv4: string[], ipv6: string[]): string | null {
  if (ipv4.length > 0) return ipv4[0];
  if (ipv6.length > 0) return ipv6[0];
  return null;
}

function canonicalIp(ip: string): string {
  return ip.trim().toLowerCase();
}

export function resolveWithCache(
  host: string,
  resolver: string,
  timeoutMs: number,
  cache: { get: (h: string) => Promise<DnsResult | null>; set: (h: string, r: DnsResult) => Promise<void> },
): Promise<DnsResult> {
  return cache.get(host).then(async (cached) => {
    if (cached) return cached;
    const r = await resolveHost(host, resolver, timeoutMs);
    await cache.set(host, r);
    log.info('dns_resolved', { host, ipv4_count: r.ipv4.length, ipv6_count: r.ipv6.length });
    return r;
  });
}
