// Geo service: resolve host → IP → country, with dual caching (DNS + IP).

import type { CountryCode } from '../types';
import type { Repository } from '../database/repository';
import { resolveHost, chooseRepresentativeIp, isIpLiteral } from './dns';
import { lookupCountry } from './ipgeo';
import { createLogger } from '../monitoring/logging';

const log = createLogger('geo');

export interface GeoServiceOptions {
  dnsResolver: string;
  dnsTimeoutMs: number;
}

/**
 * Determine the country for a config's server.
 * Returns the lowercase ISO alpha-2 code, or 'xx' if unknown.
 */
export async function resolveCountry(
  server: string,
  repo: Repository,
  opts: GeoServiceOptions,
): Promise<CountryCode> {
  try {
    // 1. If the server is already an IP literal, look it up directly.
    if (isIpLiteral(server)) {
      return await countryForIp(server, repo);
    }

    // 2. Check DNS cache.
    const hostname = server.toLowerCase().trim();
    const cachedDns = await repo.getDnsCache(hostname);
    let ip: string | null = null;
    if (cachedDns) {
      ip = chooseRepresentativeIp(cachedDns.ipv4?.split(',').filter(Boolean) ?? [], cachedDns.ipv6?.split(',').filter(Boolean) ?? []);
    }
    if (!ip) {
      const r = await resolveHost(hostname, opts.dnsResolver, opts.dnsTimeoutMs);
      await repo.setDnsCache(hostname, r.ipv4, r.ipv6, r.ttl);
      ip = chooseRepresentativeIp(r.ipv4, r.ipv6);
    }

    if (!ip) {
      log.warn('country_unresolvable', { server: hostname });
      return 'xx';
    }

    return await countryForIp(ip, repo);
  } catch (e) {
    log.warn('country_lookup_failed', { server });
    return 'xx';
  }
}

async function countryForIp(ip: string, repo: Repository): Promise<CountryCode> {
  // 1. IP cache.
  const cached = await repo.getIpCountry(ip);
  if (cached) {
    if (cached === '0') return 'xx'; // cached miss
    return cached as CountryCode;
  }

  // 2. GeoIP lookup.
  let country: CountryCode | null = null;
  try {
    country = lookupCountry(ip);
  } catch {
    country = null;
  }

  // 3. Persist (including misses, to avoid repeat lookups).
  if (!country) {
    await repo.setIpCountry(ip, '0', 'geoip-miss');
    return 'xx';
  }
  await repo.setIpCountry(ip, country, 'geoip');
  return country;
}
