// IP-geolocation engine (IPv4 + IPv6) using an in-memory, sorted range set
// with binary search. Zero external calls at lookup time; country.bin/CSV is
// bundled as a Worker asset for sub-millisecond, deterministic lookups.
//
// The database is loaded from a compact JSON/text range file produced by
// `scripts/build-geoip.mjs` from a daily rebuilt source (ip2c country.csv or
// MaxMind GeoLite2 blocks CSV). Until a database asset is bound, public IPs
// resolve to UNKNOWN ('xx'); reserved/private ranges are always classified
// correctly by `geo/reserved.ts` without any database.

import type { CountryCode } from '../types';
import { isReservedOrPrivate } from './reserved';

export interface GeoRange {
  start: bigint; // inclusive
  end: bigint; // inclusive
  country: CountryCode;
}

let ranges: GeoRange[] | null = null;
let rangesLoaded = false;

/** Convert an IPv4 dotted-quad to a 32-bit bigint (fits IPv6 space via ::ffff mapping is NOT used). */
export function ipv4ToBigInt(ip: string): bigint {
  const parts = ip.split('.').map((p) => parseInt(p, 10));
  if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) {
    throw new Error(`invalid IPv4: ${ip}`);
  }
  return ((BigInt(parts[0]) << 24n) | (BigInt(parts[1]) << 16n) | (BigInt(parts[2]) << 8n) | BigInt(parts[3]));
}

/** Convert an IPv6 address to a 128-bit bigint. */
export function ipv6ToBigInt(ip: string): bigint {
  let s = ip.trim().toLowerCase().replace(/^\[|\]$/g, '');
  // Expand "::".
  if (s.includes('::')) {
    const [l, r] = s.split('::');
    const lg = l ? l.split(':') : [];
    const rg = r ? r.split(':') : [];
    const missing = 8 - lg.length - rg.length;
    s = [...lg, ...new Array(missing).fill('0'), ...rg].join(':');
  }
  const groups = s.split(':');
  if (groups.length !== 8) throw new Error(`invalid IPv6: ${ip}`);
  let out = 0n;
  for (const g of groups) {
    out = (out << 16n) | BigInt(parseInt(g || '0', 16));
  }
  return out;
}

/** Convert an IP (v4 or v6) to a comparable bigint (v4 mapped into low 32 bits of 128-bit space). */
export function ipToBigInt(ip: string): bigint {
  if (ip.includes(':')) return ipv6ToBigInt(ip);
  // IPv4 → represent in the same 128-bit space as a v4-mapped-style value.
  return ipv4ToBigInt(ip);
}

/** Load a sorted range list and enable lookups. Called once at startup / on change. */
export function loadGeoRanges(input: GeoRange[]): void {
  // Sort by start for binary search; validate non-overlap is the caller's concern.
  ranges = [...input].sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
  rangesLoaded = true;
}

/**
 * Load from the ip2c `country.csv` text format (daily-rebuilt, lossless).
 * Format: lines of either a family marker (`4`/`6`) or `<start> <countryCode>`
 * where each start owns the range up to the next start in the same family.
 * Tolerant to comma or whitespace separators.
 */
export function loadIp2cCsv(text: string): void {
  const out: GeoRange[] = [];
  let family: 4 | 6 | null = null;
  const pending: { start: bigint; country: CountryCode }[] = [];

  const flush = () => {
    pending.sort((a, b) => (a.start < b.start ? -1 : a.start > b.start ? 1 : 0));
    for (let i = 0; i < pending.length; i++) {
      const end = i + 1 < pending.length ? pending[i + 1].start - 1n : familyMax(family!);
      out.push({ start: pending[i].start, end, country: pending[i].country });
    }
    pending.length = 0;
  };

  for (const rawLine of text.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    if (line === '4' || line === '6') {
      if (family !== null) flush();
      family = line === '4' ? 4 : 6;
      continue;
    }
    if (family === null) continue;
    const parts = line.split(/,|\s+/).filter(Boolean);
    if (parts.length < 2) continue;
    const ipStr = parts[0];
    const country = parts[parts.length - 1].toLowerCase().trim();
    if (country.length !== 2) continue;
    try {
      const start = family === 4 ? ipv4ToBigInt(ipStr) : ipv6ToBigInt(ipStr);
      pending.push({ start, country });
    } catch {
      /* skip malformed line */
    }
  }
  if (family !== null) flush();
  loadGeoRanges(out);
}

function familyMax(f: 4 | 6): bigint {
  return f === 4 ? (1n << 32n) - 1n : (1n << 128n) - 1n;
}

/** Load from a JSON array of {start,end,country} (from scripts/build-geoip.mjs). */
export function loadGeoJson(json: string): void {
  const parsed = JSON.parse(json) as Array<{ start: string; end: string; country: string }>;
  loadGeoRanges(
    parsed.map((r) => ({ start: BigInt(r.start), end: BigInt(r.end), country: r.country.toLowerCase() as CountryCode })),
  );
}

/**
 * Look up a country for an IP. Returns the ISO alpha-2 code (lowercase) or null.
 * Reserved/private ranges always resolve via a static check, independent of DB.
 */
export function lookupCountry(ip: string): CountryCode | null {
  const ipNorm = ip.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (isReservedOrPrivate(ipNorm)) return 'xx';

  if (!rangesLoaded || !ranges) return null;

  const value = ipToBigInt(ipNorm);
  // Binary search: find the last range whose start <= value.
  let lo = 0;
  let hi = ranges.length - 1;
  let found: GeoRange | null = null;
  while (lo <= hi) {
    const mid = (lo + hi) >> 1;
    const r = ranges[mid];
    if (r.start <= value) {
      found = r;
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  if (!found) return null;
  if (value <= found.end) return found.country;
  return null;
}

export function isGeoLoaded(): boolean {
  return rangesLoaded && (ranges?.length ?? 0) > 0;
}
