// Reserved / private / special-use IP classification (always → UNKNOWN 'xx')
// so we never attribute a country to a non-public IP, regardless of DB state.

export function isReservedOrPrivate(ip: string): boolean {
  if (ip.includes(':')) return isReservedIpv6(ip);
  return isReservedIpv4(ip);
}

function isReservedIpv4(ip: string): boolean {
  const parts = ip.split('.').map((p) => parseInt(p, 10));
  if (parts.length !== 4 || parts.some((p) => Number.isNaN(p) || p < 0 || p > 255)) return true; // invalid → reserved
  const [a, b] = parts;
  // 0.0.0.0/8
  if (a === 0) return true;
  // 10.0.0.0/8
  if (a === 10) return true;
  // 100.64.0.0/10 (CGNAT)
  if (a === 100 && b >= 64 && b <= 127) return true;
  // 127.0.0.0/8
  if (a === 127) return true;
  // 169.254.0.0/16 (link-local)
  if (a === 169 && b === 254) return true;
  // 172.16.0.0/12
  if (a === 172 && b >= 16 && b <= 31) return true;
  // 192.0.0.0/24, 192.0.2.0/24 (TEST-NET), 192.168.0.0/16
  if (a === 192 && (b === 0 || b === 168 || (b === 0 && parts[2] === 2))) return true;
  // 198.18.0.0/15 (benchmark), 198.51.100.0/24 (TEST-NET-2), 203.0.113.0/24 (TEST-NET-3)
  if (a === 198 && (b === 18 || b === 19 || (b === 51 && parts[2] === 100))) return true;
  if (a === 203 && b === 0 && parts[2] === 113) return true;
  // 224.0.0.0/4 (multicast) and 240.0.0.0/4 (reserved)
  if (a >= 224) return true;
  // 255.255.255.255
  if (a === 255 && b === 255 && parts[2] === 255 && parts[3] === 255) return true;
  return false;
}

function isReservedIpv6(ip: string): boolean {
  let s = ip.trim().toLowerCase().replace(/^\[|\]$/g, '');
  if (s.includes('::')) {
    const [l, r] = s.split('::');
    const lg = l ? l.split(':') : [];
    const rg = r ? r.split(':') : [];
    const missing = 8 - lg.length - rg.length;
    s = [...lg, ...new Array(missing).fill('0'), ...rg].join(':');
  }
  const groups = s.split(':');
  if (groups.length !== 8) return true; // invalid → treat reserved
  const g0 = groups[0];
  const g1 = groups[1];
  // ::/128 unspecified
  if (groups.every((g) => g === '0' || g === '0000')) return true;
  // ::1/128 loopback
  if (groups.slice(0, 7).every((g) => g === '0') && groups[7] === '1') return true;
  // fc00::/7 (ULA), fe80::/10 (link-local)
  const firstByte = parseInt(g0.slice(0, 2), 16);
  if (g0.startsWith('fc') || g0.startsWith('fd')) return true;
  if (g0.startsWith('fe8') || g0.startsWith('fe9') || g0.startsWith('fea') || g0.startsWith('feb')) return true;
  // ff00::/8 multicast
  if (g0.startsWith('ff')) return true;
  // 2001:db8::/32 documentation
  if (g0 === '2001' && g1.startsWith('db8') ) return true;
  // 2001::/32 Teredo, 2001:10::/28, etc. — leave general; they map to public (rarely used).
  // v4-mapped ::ffff:a.b.c.d — classify via v4
  if (g0 === '0' && g1 === '0' && groups[2] === '0' && groups[3] === '0' && groups[4] === '0' && groups[5] === 'ffff') {
    const v4 = `${parseInt(groups[6].slice(0, 2), 16)}.${parseInt(groups[6].slice(2), 16)}.${parseInt(groups[7].slice(0, 2), 16)}.${parseInt(groups[7].slice(2), 16)}`;
    return isReservedIpv4(v4);
  }
  void firstByte;
  return false;
}
