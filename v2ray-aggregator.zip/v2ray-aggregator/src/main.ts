// Main entrypoint for the Cloudflare Worker.
//
// Routes:
//   GET  /health          → liveness/readiness
//   POST /webhook         → Telegram update ingress (primary new-message path)
//   ANY  /admin/*         → admin panel (password + admin-id gated)
//   cron trigger          → fallback/heartbeat source scan (getUpdates polling)
//   GET  /                → basic info
//
// Durable Object exports (PublisherQueue, NpvDecoderSingleton) are registered
// here for Wrangler.

import type { Env } from './types';
import { Repository } from './database/repository';
import { loadConfig } from './config';
import { TelegramClient, type TgUpdate } from './telegram/client';
import { handleIncomingUpdate, pollUpdates, type ListenerOptions } from './telegram/source_listener';
import { handleAdmin } from './web/admin_panel';
import { handleBotCommand, parseCommand } from './telegram/admin_commands';
import { publisherStub } from './queue/producer';
import { createLogger } from './monitoring/logging';
import { describeError } from './monitoring/errors';

// Durable Object classes (exported for wrangler binding).
export { PublisherQueue } from './queue/publisher';
export { NpvDecoderSingleton } from './security/npv_decoder_do';

const log = createLogger('main');

// ---------------------------------------------------------------------------
// Helpers to build the shared dependencies once per request.
// ---------------------------------------------------------------------------

function buildListenerOptions(_env: Env, cfg: ReturnType<typeof loadConfig>): ListenerOptions {
  return {
    processor: {
      dnsResolver: cfg.dnsResolver,
      dnsTimeoutMs: cfg.dnsTimeoutMs,
      strategy: cfg.queueStrategy,
      npvMaxFileBytes: cfg.npvMaxFileBytes,
    },
  };
}

async function loadGeoDatabase(env: Env): Promise<void> {
  // Optional: load a bundled GeoIP database. If absent, country lookups degrade to
  // 'xx' for public IPs (reserved ranges are still classified correctly without a
  // database). Supported sources, tried in order:
  //   1. env.GEOIP_JSON (a string of the ranges JSON from scripts/build-geoip.mjs)
  //   2. env.GEOIP_CSV  (the raw ip2c country.csv text)
  //   3. env.GEOIP      (a Uint8Array asset binding containing either)
  try {
    const { loadGeoJson, loadIp2cCsv, isGeoLoaded } = await import('./geo/ipgeo');
    if (isGeoLoaded()) return;

    const jsonStr = env.GEOIP_JSON as string | undefined;
    if (jsonStr) {
      loadGeoJson(jsonStr);
      log.info('geoip_loaded', { source: 'json' });
      return;
    }

    const csvStr = env.GEOIP_CSV as string | undefined;
    if (csvStr) {
      loadIp2cCsv(csvStr);
      log.info('geoip_loaded', { source: 'csv' });
      return;
    }

    if (env.GEOIP) {
      const text = new TextDecoder().decode(env.GEOIP as unknown as Uint8Array);
      const trimmed = text.trimStart();
      if (trimmed.startsWith('[') || trimmed.startsWith('{')) loadGeoJson(text);
      else loadIp2cCsv(text);
      log.info('geoip_loaded', { source: 'asset' });
    }
  } catch (e) {
    log.warn('geoip_load_failed', { error: describeError(e).message });
  }
}

export default {
  async fetch(request: Request, env: Env, _ctx: ExecutionContext): Promise<Response> {
    const url = new URL(request.url);
    const path = url.pathname;

    // --- Health ---
    if (request.method === 'GET' && path === '/health') {
      const repo = new Repository(env.DB);
      try {
        const sources = await repo.listSources();
        const queue = await repo.queueLength();
        return json({ ok: true, sources: sources.length, queue });
      } catch (e) {
        return json({ ok: false, error: describeError(e).message }, 500);
      }
    }

    // --- Webhook (Telegram) ---
    if (request.method === 'POST' && path === '/webhook') {
      return handleWebhook(request, env);
    }

    // --- Webhook setup helper (admin) ---
    if (request.method === 'GET' && path === '/__webhook_setup') {
      return setupWebhook(request, env);
    }

    // --- Admin panel ---
    const cfgPath = loadConfig(env).adminPanelPath || '/admin';
    if (path === cfgPath || path.startsWith(`${cfgPath}/`)) {
      return handleAdmin(request, env, path);
    }

    // --- Root info ---
    if (request.method === 'GET' && path === '/') {
      return html(
        'V2Ray/Xray Telegram Aggregator — running. <a href="' +
          cfgPath +
          '">Admin panel</a> · <a href="/health">health</a>',
      );
    }

    return json({ ok: false, error: 'not found' }, 404);
  },

  async scheduled(_controller: ScheduledController, env: Env, ctx: ExecutionContext): Promise<void> {
    ctx.waitUntil(runCronScan(env));
  },
};

async function handleWebhook(request: Request, env: Env): Promise<Response> {
  // Optional webhook secret: reject requests that don't carry it.
  const expectedSecret = env.WEBHOOK_SECRET;
  if (expectedSecret) {
    const provided = request.headers.get('x-telegram-bot-api-secret-token');
    if (!provided || provided !== expectedSecret) {
      return json({ ok: false, error: 'unauthorized' }, 403);
    }
  }

  const repo = new Repository(env.DB);
  const cfg = loadConfig(env, await repo.getSettings());
  const opts = buildListenerOptions(env, cfg);
  await loadGeoDatabase(env);

  let update: TgUpdate;
  try {
    update = (await request.json()) as TgUpdate;
  } catch {
    return json({ ok: false, error: 'invalid json' }, 400);
  }

  // Distinguish a bot command (private chat) from a channel post.
  if (update.message && update.message.chat && update.message.chat.type === 'private') {
    await handlePrivateMessage(update.message, repo, env);
    return json({ ok: true });
  }

  const r = await handleIncomingUpdate(update, repo, env, opts);
  return json({ ok: true, ...r });
}

async function setupWebhook(request: Request, env: Env): Promise<Response> {
  const token = env.TELEGRAM_BOT_TOKEN ?? '';
  const tg = new TelegramClient(token);
  const url = new URL(request.url);
  const webhookUrl = env.SET_WEBHOOK_URL ?? `${url.origin}/webhook`;
  const okSet = await tg.setWebhook(webhookUrl, env.WEBHOOK_SECRET);
  return json({ ok: okSet, webhookUrl });
}

async function handlePrivateMessage(message: import('./telegram/client').TgMessage, repo: Repository, env: Env): Promise<void> {
  const tg = new TelegramClient(env.TELEGRAM_BOT_TOKEN ?? '');
  const parsed = parseCommand(message.text);
  if (!parsed) return;

  const userId = message.from?.id ?? message.chat?.id ?? 0;
  await handleBotCommand(
    {
      userId,
      username: message.from?.username,
      chatId: Number(message.chat?.id ?? userId),
      command: parsed.command,
      args: parsed.args,
    },
    repo,
    env,
    tg,
  );
}

async function runCronScan(env: Env): Promise<void> {
  try {
    const repo = new Repository(env.DB);
    const cfg = loadConfig(env, await repo.getSettings());
    await loadGeoDatabase(env);
    const tg = new TelegramClient(cfg.botToken);
    const opts = buildListenerOptions(env, cfg);

    await pollUpdates(repo, env, opts, tg);

    // Wake the publisher so it processes anything newly enqueued.
    const stub = publisherStub(env);
    await stub.fetch('https://do/tick', { method: 'POST', body: JSON.stringify({ type: 'tick' }) });
  } catch (e) {
    log.error('cron_scan_error', { error: describeError(e).message });
  }
}

function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });
}

function html(body: string): Response {
  return new Response(body, { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } });
}
