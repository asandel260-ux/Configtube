// Typed, categorized errors. Centralizes error isolation so one failure never
// crashes the whole pipeline.

export type ErrorCategory =
  | 'telegram'
  | 'dns'
  | 'geoip'
  | 'malformed'
  | 'unsupported'
  | 'npv'
  | 'db'
  | 'download'
  | 'publish'
  | 'ratelimit'
  | 'auth'
  | 'other';

export class AppError extends Error {
  readonly category: ErrorCategory;
  readonly context: Record<string, unknown>;
  readonly retryable: boolean;

  constructor(
    category: ErrorCategory,
    message: string,
    opts: { context?: Record<string, unknown>; retryable?: boolean; cause?: unknown } = {},
  ) {
    super(message);
    this.name = 'AppError';
    this.category = category;
    this.context = opts.context ?? {};
    this.retryable = opts.retryable ?? false;
    if (opts.cause) (this as { cause?: unknown }).cause = opts.cause;
  }
}

export function isAppError(e: unknown): e is AppError {
  return e instanceof Error && (e as AppError).name === 'AppError';
}

/** Extract a safe, category-tagged description from any thrown value. */
export function describeError(e: unknown): { category: ErrorCategory; message: string } {
  if (isAppError(e)) return { category: e.category, message: e.message };
  if (e instanceof Error) return { category: 'other', message: e.message };
  return { category: 'other', message: String(e) };
}
