// Structured logging. Credential-safe: never log UUIDs/passwords/private keys.
// All V2Ray configs are represented by their deterministic hash in logs.

export type LogLevel = 'DEBUG' | 'INFO' | 'WARN' | 'ERROR';

// Fields that must NEVER appear in logs.
const REDACT_KEYS = new Set(['uuid', 'password', 'public_key', 'private_key', 'id', 'ps']);

export interface Logger {
  debug(event: string, fields?: Record<string, unknown>): void;
  info(event: string, fields?: Record<string, unknown>): void;
  warn(event: string, fields?: Record<string, unknown>): void;
  error(event: string, fields?: Record<string, unknown>): void;
}

function safeFields(fields?: Record<string, unknown>): Record<string, unknown> {
  if (!fields) return {};
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(fields)) {
    if (REDACT_KEYS.has(k)) {
      out[k] = '[REDACTED]';
      continue;
    }
    // Truncate any value that could be a config blob.
    if (typeof v === 'string' && v.length > 256) {
      out[k] = v.slice(0, 256) + '…';
      continue;
    }
    out[k] = v;
  }
  return out;
}

function emit(level: LogLevel, event: string, fields?: Record<string, unknown>) {
  const line: Record<string, unknown> = {
    t: new Date().toISOString(),
    level,
    event,
    ...safeFields(fields),
  };
  const msg = JSON.stringify(line);
  const prev = (globalThis as unknown as { __logSink?: (level: string, ...rest: unknown[]) => void })
    .__logSink;
  if (prev) {
    prev(level.toLowerCase(), JSON.stringify(line));
    return;
  }
  // Fallback console.
  if (level === 'ERROR') console.error(msg);
  else if (level === 'WARN') console.warn(msg);
  else console.log(msg);
}

export function createLogger(context?: string): Logger {
  const ctx = context ? { ctx: context } : undefined;
  return {
    debug: (e, f) => emit('DEBUG', e, { ...ctx, ...f }),
    info: (e, f) => emit('INFO', e, { ...ctx, ...f }),
    warn: (e, f) => emit('WARN', e, { ...ctx, ...f }),
    error: (e, f) => emit('ERROR', e, { ...ctx, ...f }),
  };
}

export const log = createLogger('app');
