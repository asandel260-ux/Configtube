// Core pipeline orchestrator. Strongly typed, doesn't throw — every stage is
// isolated so a failure in one config/message never stops the system.
//
//   source message → extract configs (text + .npv) → normalize → validate →
//   fingerprint → dedup → geo (country) → enqueue

import type { Env, FileRef, ProcessedConfig, QueueStrategy, SourceMessage, V2rayConfig } from '../types';
import { Repository } from '../database/repository';
import { extractAllConfigUris } from '../extraction/text_extractor';
import { parseUri } from '../extraction/uri_parser';
import { decodeNpvSafe } from '../extraction/npv/decoder';
import { normalizeConfig, canonicalize } from '../config/normalizer';
import { validateConfig } from '../config/validator';
import { fingerprint } from '../config/fingerprint';
import { buildUri } from '../config/build_uri';
import { resolveCountry } from '../geo/geo';
import { enqueueConfigs } from '../queue/producer';
import { TelegramClient } from '../telegram/client';
import { AppError, describeError } from '../monitoring/errors';
import { createLogger } from '../monitoring/logging';

const log = createLogger('pipeline');

export interface ProcessResult {
  configsFound: number;
  enqueued: number;
  duplicates: number;
  rejected: number;
  npvFound: number;
  npvDecoded: number;
  npvFailed: number;
}

export interface ProcessorOptions {
  dnsResolver: string;
  dnsTimeoutMs: number;
  strategy: QueueStrategy;
  npvMaxFileBytes: number;
}

/**
 * Process a single source message into 0..N queued configs.
 * Never throws: returns a structured result. Errors are logged + recorded.
 */
export async function processSourceMessage(
  message: SourceMessage,
  repo: Repository,
  env: Env,
  opts: ProcessorOptions,
): Promise<ProcessResult> {
  const result: ProcessResult = {
    configsFound: 0,
    enqueued: 0,
    duplicates: 0,
    rejected: 0,
    npvFound: 0,
    npvDecoded: 0,
    npvFailed: 0,
  };

  const configs: V2rayConfig[] = [];

  // 1. Extract URIs from text + caption.
  const textSources = [message.text, message.caption].filter((t): t is string => !!t);
  const bodyText = textSources.join('\n');
  const uriMatches = extractAllConfigUris(bodyText);
  for (const m of uriMatches) {
    try {
      configs.push(parseUri(m.uri));
    } catch (e) {
      result.rejected++;
      await repo.logError((e as AppError).category ?? 'malformed', describeError(e).message, {
        source_message: message.message_id,
      });
      await repo.incrementStat('configs_rejected');
      log.info('config_parse_failed', { reason: describeError(e).message });
    }
  }

  // 2. Process .npv attachments.
  const docs = (message.documents ?? []).filter((d) => isNpv(d));
  if (docs.length > 0) result.npvFound = docs.length;

  for (const doc of docs) {
    try {
      const cfg = await decodeNpvDocument(doc, repo, env, opts);
      if (cfg) {
        configs.push(cfg);
        result.npvDecoded++;
      } else {
        result.npvFailed++;
      }
    } catch (e) {
      result.npvFailed++;
      await repo.incrementStat('npv_decoding_failures');
      await repo.logError('npv', describeError(e).message, { file: doc.name });
      log.info('npv_decode_failed', { filename: doc.name, reason: describeError(e).message });
    }
  }

  if (docs.length > 0) await repo.incrementStat('npv_files_detected', docs.length);
  if (result.npvDecoded > 0) await repo.incrementStat('npv_decoded', result.npvDecoded);

  result.configsFound = configs.length;
  if (configs.length > 0) await repo.incrementStat('configs_detected', configs.length);

  // 3. Normalize → validate → fingerprint → dedup → geo → enqueue.
  const processed: ProcessedConfig[] = [];
  const sourceUrl = sourceMessageUrl(message.channel_id, message.message_id);

  for (const raw of configs) {
    try {
      const config = normalizeConfig(raw);
      const encoded = raw.raw ?? buildUri(config);
      const validation = validateConfig(config);
      if (!validation.valid) {
        result.rejected++;
        await repo.incrementStat('configs_rejected');
        await repo.logError('malformed', validation.reason ?? 'invalid', { server: config.server });
        log.info('config_rejected', { reason: validation.reason, server: config.server });
        continue;
      }

      const hash = await fingerprint(config);
      const normalized = canonicalize(config);

      // Dedup.
      const inserted = await repo.insertConfig({
        id: crypto.randomUUID(),
        config_hash: hash,
        config,
        normalized,
        country: 'xx', // resolved below (placeholder, overwritten after geo)
        attribution: {
          source_channel: message.channel_id,
          source_message_id: message.message_id,
          source_message_url: sourceUrl,
          first_seen: new Date().toISOString(),
        },
        encoded_config: encoded,
      });

      if (inserted === 'duplicate') {
        result.duplicates++;
        await repo.incrementStat('duplicates_detected');
        log.info('duplicate_config', { hash });
        continue;
      }

      // Geo (resolve country from resolved IP).
      const country = await resolveCountry(config.server, repo, {
        dnsResolver: opts.dnsResolver,
        dnsTimeoutMs: opts.dnsTimeoutMs,
      });
      await repo.incrementStat('countries_detected');

      processed.push({
        id: crypto.randomUUID(),
        config_hash: hash,
        config,
        normalized,
        country,
        attribution: {
          source_channel: message.channel_id,
          source_message_id: message.message_id,
          source_message_url: sourceUrl,
          first_seen: new Date().toISOString(),
        },
        encoded_config: encoded,
      });

      // Persist the resolved country on the config row.
      await repo.setConfigCountry(hash, country);
      log.info('country_detected', { country, server: config.server });
    } catch (e) {
      result.rejected++;
      await repo.incrementStat('configs_rejected');
      await repo.logError(describeError(e).category, describeError(e).message, {});
    }
  }

  // 4. Enqueue all newly processed configs.
  if (processed.length > 0) {
    result.enqueued = await enqueueConfigs(processed, {
      repo,
      env,
      strategy: opts.strategy,
      timestamp: message.timestamp ?? Math.floor(Date.now() / 1000),
    });
  }

  log.info('processing_complete', {
    message_id: message.message_id,
    configs: result.configsFound,
    enqueued: result.enqueued,
    duplicates: result.duplicates,
    rejected: result.rejected,
    npv: result.npvFound,
    npv_decoded: result.npvDecoded,
  });

  return result;
}

function isNpv(doc: FileRef): boolean {
  const name = (doc.name ?? '').toLowerCase();
  if (name) return /\.npv(t|4)?$/i.test(name) || name.endsWith('.npv');
  // Fall back to mime/extension-less detection: treat small binary docs with the
  // tell-tale extension as npv only when name is present; otherwise skip.
  return false;
}

async function decodeNpvDocument(
  doc: FileRef,
  repo: Repository,
  env: Env,
  opts: ProcessorOptions,
): Promise<V2rayConfig | null> {
  const tg = new TelegramClient(env.TELEGRAM_BOT_TOKEN ?? '');
  const file = await tg.getFile(doc.file_id);
  if (!file.file_path) {
    throw new AppError('download', 'npv file has no file_path', { context: { file_id: doc.file_id } });
  }
  const buf = await tg.downloadFile(file.file_path, opts.npvMaxFileBytes);

  // Isolated decode (could route through the DO; direct call is equivalent for
  // pure logic and avoids a serialization round-trip). Kept pure + budgeted.
  const res = decodeNpvSafe(buf, doc.name, opts.npvMaxFileBytes);

  if (res.variant === 'unlocked-json' && res.config) {
    return res.config;
  }
  // Encrypted / unknown / no-config → no usable config. Record and move on.
  await repo.logError('npv', res.reason ?? 'npv has no usable config', { file: doc.name, variant: res.variant });
  return null;
}

function sourceMessageUrl(channelId: string, messageId: number): string {
  // Telegram public message link: t.me/<channel>/<message_id>
  const cleanc = channelId.startsWith('@') ? channelId.slice(1) : channelId;
  return `https://t.me/${cleanc}/${messageId}`;
}
