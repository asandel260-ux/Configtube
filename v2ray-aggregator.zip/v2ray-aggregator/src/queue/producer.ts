// Queue producer: convert ProcessedConfigs into durable queue rows and wake the
// publisher Durable Object.

import type { ProcessedConfig } from '../types';
import type { Repository } from '../database/repository';
import type { Env } from '../types';
import { computeSortKey } from './strategies';
import { createLogger } from '../monitoring/logging';

const log = createLogger('queue:producer');

export interface ProducerWiring {
  repo: Repository;
  env: Env;
  strategy: import('../types').QueueStrategy;
  timestamp: number;
  sourcePriority?: (channelId: string) => number;
}

/**
 * Enqueue a set of processed configs (dedup already applied by caller).
 * Returns the number actually enqueued.
 */
export async function enqueueConfigs(items: ProcessedConfig[], wiring: ProducerWiring): Promise<number> {
  let enqueued = 0;
  for (let i = 0; i < items.length; i++) {
    const p = items[i];
    const priority = wiring.sourcePriority ? wiring.sourcePriority(p.attribution.source_channel) : 0;
    const sortKey = computeSortKey({
      strategy: wiring.strategy,
      configIndex: i,
      timestamp: wiring.timestamp,
      country: p.country,
      sourceChannel: p.attribution.source_channel,
      sourcePriority: priority,
    });
    await wiring.repo.enqueue(p, sortKey, priority);
    enqueued++;
  }
  if (enqueued > 0) {
    await wiring.repo.incrementStat('queued_total', enqueued);
    log.info('configs_queued', { count: enqueued });
    await wakePublisher(wiring.env);
  }
  return enqueued;
}

/** Wake the publisher Durable Object (non-blocking, best-effort). */
export async function wakePublisher(env: Env): Promise<void> {
  try {
    const id = env.PUBLISHER_QUEUE.idFromName('publisher');
    const stub = env.PUBLISHER_QUEUE.get(id);
    await stub.fetch('https://do/tick', { method: 'POST', body: JSON.stringify({ type: 'tick' }) });
  } catch (e) {
    // The publisher also runs on its own alarm, so a failed wake is non-fatal.
    log.warn('publisher_wake_failed', { error: String(e) });
  }
}

/** Get a stable stub for the publisher DO (used by admin, cron, etc.). */
export function publisherStub(env: Env): DurableObjectStub {
  const id = env.PUBLISHER_QUEUE.idFromName('publisher');
  return env.PUBLISHER_QUEUE.get(id);
}

/** Get a stable stub for the NPV decoder DO. */
export function npvDecoderStub(env: Env): DurableObjectStub {
  const id = env.NPV_DECODER.idFromName('npv-decoder');
  return env.NPV_DECODER.get(id);
}
