// Publisher Durable Object — the single-flight queue consumer + scheduler.
//
// Why a Durable Object:
//  * Exactly one actor drains the queue at a time (no double-publishing).
//  * Its alarm provides the "wait ≥ 60s between posts" cadence without a long-
//    running process (Workers can't sleep indefinitely).
//  * Its storage holds the claim token so crash recovery can release stuck items.
//
// Self-contained: Durable Objects are re-instantiated on every alarm tick with
// no preserved memory, so everything is read from `env` (bindings + vars +
// secrets) and `state.storage` (durable state) on each construction.

import { Repository, type QueueItem } from '../database/repository';
import { TelegramClient } from '../telegram/client';
import { buildPost, buildPostPlain } from '../telegram/formatter';
import { describeError } from '../monitoring/errors';
import { createLogger } from '../monitoring/logging';

const log = createLogger('queue:publisher');

export class PublisherQueue {
  private readonly state: DurableObjectState;
  private readonly env: PublisherEnv;
  private repo: Repository | null = null;

  constructor(state: DurableObjectState, env: PublisherEnv) {
    this.state = state;
    this.env = env;
  }

  private get repoInstance(): Repository {
    if (!this.repo) this.repo = new Repository(this.env.DB);
    return this.repo;
  }

  async fetch(request: Request): Promise<Response> {
    const req = (await request.json()) as PublisherRequest;
    switch (req.type) {
      case 'tick':
        await this.tick();
        return json({ ok: true });
      case 'status':
        return json({
          ok: true,
          hasAlarm: (await this.state.storage.getAlarm()) !== null,
        });
      case 'reset-stuck':
        await this.repoInstance.requeueClaimed(await this.claimToken());
        return json({ ok: true });
      default:
        return json({ ok: false, error: 'unknown request type' }, 400);
    }
  }

  async tick(): Promise<void> {
    const repo = this.repoInstance;
    const cfg = this.config();

    // 1. Release stuck items from a previous generation.
    const claimToken = await this.claimToken();
    await repo.requeueClaimed(claimToken);

    // 2. Respect global pause.
    const paused = (await repo.getSetting('paused')) === '1';
    if (paused) {
      await this.scheduleNext();
      return;
    }

    // 3. Claim + publish the next item.
    const item = await repo.claimNextQueueItem(claimToken);
    if (!item) {
      log.debug('publisher_idle');
      await this.scheduleNext(/* sparse */ true);
      return;
    }

    const published = await this.publishOne(item, repo, cfg);

    if (published != null && published >= 0) {
      await repo.completeQueueItem(item.queue_id, published);
      await repo.incrementStat('configs_published');
      log.info('config_published', { hash: item.config_hash, destination_message_id: published });
    } else if (published === -1 || published === -2) {
      // -1: already published (duplicate) → complete without posting.
      // -2: permanent malformed → complete without posting (avoid infinite loop).
      await repo.completeQueueItem(item.queue_id, 0);
      await repo.incrementStat(published === -1 ? 'duplicates_detected' : 'configs_rejected');
      log.info('publish_skipped', { hash: item.config_hash, code: published });
    } else {
      // null: transient failure → requeue with backoff.
      const fails = item.attempts + 1;
      const delayMs = Math.min(600000, 1000 * Math.pow(2, fails));
      await repo.failQueueItem(item.queue_id, delayMs);
      await repo.incrementStat('publishing_failures');
      log.warn('publish_failed', { hash: item.config_hash, attempts: fails });
    }

    await this.scheduleNext();
  }

  /** Returns destination message id, a negative sentinel, or null (transient). */
  private async publishOne(item: QueueItem, repo: Repository, cfg: Cfg): Promise<number | null> {
    // Idempotence guard: skip if this config already published.
    if (await repo.isAlreadyPublished(item.config_hash)) {
      return -1;
    }

    const tg = new TelegramClient(cfg.botToken);
    const sourceUrl = item.source_message_url ?? `t.me/${item.source_channel ?? ''}`;
    const post = buildPost(item.encoded_config, item.country, sourceUrl, undefined);

    try {
      // Send first, then write the ledger. The single-flight DO + isAlreadyPublished
      // guard makes dupes near-impossible, and a timeout-but-accepted send is handled
      // on the next tick by the ledger check + attempt counting (not a double post).
      const msg = await tg.sendMessage(cfg.destinationChannel, post.text, {
        parse_mode: post.parse_mode,
        disable_web_page_preview: true,
      });

      const publishId = crypto.randomUUID();
      await repo.claimPublish(item.config_hash, publishId);
      await repo.recordPublished(
        publishId,
        item.config_id,
        item.config_hash,
        msg.message_id,
        item.country,
        item.protocol,
        item.source_channel ?? '',
        sourceUrl,
      );
      return msg.message_id;
    } catch (e) {
      const { category, message } = describeError(e);
      if (category === 'ratelimit') {
        await repo.logError(category, message, { hash: item.config_hash });
        return null;
      }
      if (category === 'telegram' && /400|403|can't parse|bad request|chat not found/i.test(message)) {
        // Likely a formatting/parse error → try a plain-text fallback once.
        try {
          const plain = buildPostPlain(item.encoded_config, item.country, sourceUrl);
          const msg = await tg.sendMessage(cfg.destinationChannel, plain, { disable_web_page_preview: true });
          const publishId = crypto.randomUUID();
          await repo.claimPublish(item.config_hash, publishId);
          await repo.recordPublished(
            publishId,
            item.config_id,
            item.config_hash,
            msg.message_id,
            item.country,
            item.protocol,
            item.source_channel ?? '',
            sourceUrl,
          );
          return msg.message_id;
        } catch (e2) {
          await repo.logError('publish', describeError(e2).message, { hash: item.config_hash });
          return null;
        }
      }
      await repo.logError('publish', message, { hash: item.config_hash });
      return null;
    }
  }

  private async scheduleNext(sparse = false): Promise<void> {
    const existing = await this.state.storage.getAlarm();
    if (existing !== null) return;
    const cfg = this.config();
    const intervalMs = cfg.publishIntervalMinutes * 60 * 1000;
    const delay = sparse ? Math.max(intervalMs, 30_000) : intervalMs;
    await this.state.storage.setAlarm(Date.now() + delay);
  }

  async alarm(): Promise<void> {
    await this.tick();
  }

  private async claimToken(): Promise<string> {
    let token = (await this.state.storage.get<string>('claimToken')) || null;
    if (!token) {
      token = `pub-${crypto.randomUUID()}`;
      await this.state.storage.put('claimToken', token);
    }
    return token;
  }

  private config(): Cfg {
    const rawInterval = this.env.PUBLISH_INTERVAL_MINUTES ?? '1';
    return {
      botToken: this.env.TELEGRAM_BOT_TOKEN ?? '',
      destinationChannel: this.env.DESTINATION_CHANNEL ?? '',
      publishIntervalMinutes: Math.max(1, parseInt(rawInterval, 10) || 1),
    };
  }
}

interface Cfg {
  botToken: string;
  destinationChannel: string;
  publishIntervalMinutes: number;
}

export interface PublisherRequest {
  type: 'tick' | 'status' | 'reset-stuck';
}

interface PublisherEnv {
  DB: D1Database;
  TELEGRAM_BOT_TOKEN?: string;
  DESTINATION_CHANNEL?: string;
  PUBLISH_INTERVAL_MINUTES?: string;
}

function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });
}
