// Queue ordering strategies → sort_key assignment.

import type { QueueStrategy } from '../types';

export interface QueueSortInput {
  strategy: QueueStrategy;
  configIndex: number; // 0-based index of this config within its source message
  timestamp: number; // unix seconds of discovery
  country: string;
  sourceChannel: string;
  sourcePriority: number; // higher = more important
}

/**
 * Compute a sort key (ascending = earlier publish) for a queue item.
 * The key must be deterministic and monotonic in time so 'chronological' (the
 * default) preserves discovery order.
 */
export function computeSortKey(input: QueueSortInput): number {
  switch (input.strategy) {
    case 'chronological':
      // Primary: absolute timestamp; secondary: config index within the message.
      return input.timestamp * 1000 + input.configIndex;

    case 'newest-first':
      // Invert time so newest publishes first (negate).
      return -(input.timestamp * 1000 + input.configIndex);

    case 'source-order':
      // Group by source channel (stable hash), then time.
      return hashChannel(input.sourceChannel) * 1e12 + input.timestamp * 1000 + input.configIndex;

    case 'priority-source':
      // Highest-priority source first (invert priority), then time.
      return -input.sourcePriority * 1e15 + input.timestamp * 1000 + input.configIndex;

    case 'country-balanced':
      // Round-robin by country (stable hash) is hard with a pure sort key, so we
      // approximate: spread by country hash mod, then time.
      return (hashCountry(input.country) % 997) * 1e9 + input.timestamp;

    case 'random':
      // Deterministic pseudo-random per config (so restarts don't reshuffle).
      return pseudoRandom(input.timestamp * 1000 + input.configIndex + hashChannel(input.sourceChannel));

    default:
      return input.timestamp * 1000 + input.configIndex;
  }
}

function hashChannel(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = (h * 31 + s.charCodeAt(i)) >>> 0;
  }
  return h % 1000;
}

function hashCountry(c: string): number {
  let h = 0;
  for (let i = 0; i < c.length; i++) h = (h * 31 + c.charCodeAt(i)) >>> 0;
  return h;
}

function pseudoRandom(seed: number): number {
  // xorshift — deterministic given the same seed.
  let x = seed >>> 0 || 1;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  return (x >>> 0) / 4294967295;
}
