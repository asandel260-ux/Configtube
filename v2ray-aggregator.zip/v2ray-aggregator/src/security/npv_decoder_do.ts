// NPV decoder Durable Object — isolated sandbox for decoding untrusted .npv files.
//
// Provides a hard wall-clock execution boundary (Workers have a default limit;
// we also gate work with our own budget), and isolates the pure decoder from
// the rest of the pipeline. No filesystem, no child processes, no network,
// no eval — the decoder is pure.
//
// The DO returns a typed NpvDecodeResult; on a decode that produces no usable
// config it returns { variant, reason } so the caller marks the message
// processed without queueing anything.

import { decodeNpvSafe, type NpvDecodeResult } from '../extraction/npv/decoder';
import { validateNpvInput, withTimeout, type NpvSandboxLimits } from '../extraction/npv/sandbox';
import { AppError, describeError } from '../monitoring/errors';
import { createLogger } from '../monitoring/logging';

const log = createLogger('security:npv');

export class NpvDecoderSingleton {
  private readonly env: NpvEnv;

  constructor(_state: DurableObjectState, env: NpvEnv) {
    this.env = env;
  }

  async fetch(request: Request): Promise<Response> {
    const req = (await request.json()) as NpvRequest;
    switch (req.type) {
      case 'decode': {
        const { bytes, fileName } = req;
        const limits = this.limits();
        try {
          // 1. Validate (size, traversal guards) before touching the decoder.
          const buf = bytes instanceof Uint8Array ? bytes : Uint8Array.from(Object.values(bytes ?? {}));
          validateNpvInput(buf, fileName, limits);

          // 2. Decode under a budget.
          const result = withTimeout(() => decodeNpvSafe(buf, fileName, limits.maxFileBytes), limits.decodeTimeoutMs);
          log.info('npv_decoded', { variant: result.variant, version: result.version ?? undefined, hasConfig: !!result.config?.protocol });
          return json({ ok: true, result });
        } catch (e) {
          const { message } = describeError(e);
          log.info('npv_decode_failed', { reason: message });
          return json({ ok: false, error: message });
        }
      }
      default:
        return json({ ok: false, error: 'unknown request type' }, 400);
    }
  }

  private limits(): NpvSandboxLimits {
    return {
      maxFileBytes: parseInt(this.env.NPV_MAX_FILE_BYTES ?? '262144', 10) || 262144,
      decodeTimeoutMs: parseInt(this.env.NPV_DECODE_TIMEOUT_MS ?? '3000', 10) || 3000,
    };
  }
}

export interface NpvRequest {
  type: 'decode';
  bytes?: Uint8Array | Record<string, number> | number[];
  fileName?: string;
}

interface NpvEnv {
  NPV_MAX_FILE_BYTES?: string;
  NPV_DECODE_TIMEOUT_MS?: string;
}

function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });
}

export type { NpvDecodeResult, AppError };
