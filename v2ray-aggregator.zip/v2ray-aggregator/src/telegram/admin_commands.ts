// Admin commands (Telegram bot commands), gated to authorized admin user IDs.
// Never rely on username: authorization is by numeric Telegram user id only.

import type { Env } from '../types';
import { Repository } from '../database/repository';
import { TelegramClient } from './client';
import { loadConfig } from '../config';
import { createLogger } from '../monitoring/logging';

const log = createLogger('admin');

export type CommandName =
  | 'start'
  | 'help'
  | 'addsource'
  | 'removesource'
  | 'sources'
  | 'enablesource'
  | 'disablesource'
  | 'status'
  | 'queue'
  | 'clearqueue'
  | 'config'
  | 'stats'
  | 'reprocess'
  | 'reset'
  | 'pause'
  | 'resume';

interface IncomingCommand {
  userId: number;
  username?: string;
  chatId: number;
  command: CommandName;
  args: string[];
}

export async function handleBotCommand(
  cmd: IncomingCommand,
  repo: Repository,
  env: Env,
  tg: TelegramClient,
): Promise<void> {
  try {
    const cfg = loadConfig(env, await getStoredCfg(repo));
    if (!cfg.adminUserIds.includes(cmd.userId)) {
      await tg.sendMessage(String(cmd.chatId), '⛔ Unauthorized. This is an admin-only command.');
      return;
    }
    await repo.upsertAdmin(cmd.userId, cmd.username ?? null, null);
    await dispatch(cmd, repo, env, tg, cfg);
  } catch (e) {
    log.error('admin_command_error', { command: cmd.command, error: String(e) });
    await tg.sendMessage(String(cmd.chatId), '❌ Command failed. See logs for details.').catch(() => {});
  }
}

async function getStoredCfg(repo: Repository): Promise<Record<string, string>> {
  return repo.getSettings();
}

async function dispatch(
  cmd: IncomingCommand,
  repo: Repository,
  env: Env,
  tg: TelegramClient,
  cfg: ReturnType<typeof loadConfig>,
): Promise<void> {
  void env; // commands that need raw env bindings use this via closure; kept for API stability
  switch (cmd.command) {
    case 'start':
    case 'help':
      await sendHelp(tg, cmd.chatId);
      return;

    case 'addsource':
      await addSource(cmd, repo, tg);
      return;

    case 'removesource':
      await removeSource(cmd, repo, tg);
      return;

    case 'sources':
      await listSources(repo, tg, cmd.chatId);
      return;

    case 'enablesource':
      await setEnabled(cmd, repo, tg, true);
      return;

    case 'disablesource':
      await setEnabled(cmd, repo, tg, false);
      return;

    case 'status':
      await status(repo, tg, cmd.chatId);
      return;

    case 'queue':
      await queue(repo, tg, cmd.chatId);
      return;

    case 'clearqueue':
      await clearQueue(repo, tg, cmd.chatId);
      return;

    case 'config':
      await showConfig(cfg, tg, cmd.chatId);
      return;

    case 'stats':
      await stats(repo, tg, cmd.chatId);
      return;

    case 'reprocess':
      await reprocess(cmd, repo, tg);
      return;

    case 'reset':
      await reset(cmd, repo, tg);
      return;

    case 'pause':
      await repo.setSetting('paused', '1');
      await tg.sendMessage(String(cmd.chatId), '⏸️ Publishing paused.');
      return;

    case 'resume':
      await repo.setSetting('paused', '0');
      await tg.sendMessage(String(cmd.chatId), '▶️ Publishing resumed.');
      return;

    default:
      await tg.sendMessage(String(cmd.chatId), 'Unknown command. Use /help.');
      return;
  }
}

// ---------------------------------------------------------------------------

async function sendHelp(tg: TelegramClient, chatId: number): Promise<void> {
  const text = [
    '*V2Ray Aggregator — Admin commands*',
    '',
    '/addsource <channel> [display name] — add a source channel',
    '/removesource <id|@channel> — remove a source',
    '/sources — list sources',
    '/enablesource <id> — enable a source',
    '/disablesource <id> — disable a source',
    '/status — system status',
    '/queue — view publishing queue',
    '/clearqueue — clear the queue',
    '/config — current configuration',
    '/stats — statistics',
    '/reprocess <id> <msgid> — reprocess a source message',
    '/reset <id> — reset a source processing position',
    '/pause — pause publishing',
    '/resume — resume publishing',
    '',
    'Full management is also available in the /admin web panel.',
  ].join('\n');
  await tg.sendMessage(String(chatId), text, { parse_mode: 'Markdown' });
}

async function addSource(cmd: IncomingCommand, repo: Repository, tg: TelegramClient): Promise<void> {
  if (cmd.args.length < 1) {
    await tg.sendMessage(String(cmd.chatId), 'Usage: /addsource <@channel-or-id> [display name]');
    return;
  }
  let channel = cmd.args[0].trim();
  if (!channel.startsWith('@') && !channel.startsWith('-100') && !channel.startsWith('-')) {
    channel = '@' + channel.replace(/^@/, '');
  }
  if (!channel.startsWith('@') && !/^-\d+$/.test(channel)) {
    await tg.sendMessage(String(cmd.chatId), 'Invalid channel. Use @channel or a numeric chat id.');
    return;
  }
  const displayName = cmd.args.slice(1).join(' ') || channel;
  const src = await repo.addSource({
    source_id: crypto.randomUUID(),
    telegram_channel_id: channel,
    username: channel.startsWith('@') ? channel.slice(1) : null,
    display_name: displayName,
    enabled: true,
  });
  await tg.sendMessage(String(cmd.chatId), `✅ Added source: ${src.display_name ?? channel} (${src.source_id})`);
}

async function removeSource(cmd: IncomingCommand, repo: Repository, tg: TelegramClient): Promise<void> {
  if (cmd.args.length < 1) {
    await tg.sendMessage(String(cmd.chatId), 'Usage: /removesource <id|@channel>');
    return;
  }
  const target = cmd.args[0].trim();
  let src = await repo.getSource(target);
  if (!src) src = await repo.getSourceByChannelId(target);
  if (!src) {
    await tg.sendMessage(String(cmd.chatId), 'Source not found.');
    return;
  }
  await repo.removeSource(src.source_id);
  await tg.sendMessage(String(cmd.chatId), `🗑️ Removed source: ${src.display_name ?? src.telegram_channel_id}`);
}

async function listSources(repo: Repository, tg: TelegramClient, chatId: number): Promise<void> {
  const sources = await repo.listSources();
  if (sources.length === 0) {
    await tg.sendMessage(String(chatId), 'No sources configured.');
    return;
  }
  const lines = sources.map((s) =>
    `${s.enabled ? '🟢' : '🔴'} \`${s.source_id}\` ${s.display_name ?? s.telegram_channel_id} (last: ${s.last_processed_message_id})`,
  );
  await tg.sendMessage(String(chatId), lines.join('\n'), { parse_mode: 'Markdown' });
}

async function setEnabled(cmd: IncomingCommand, repo: Repository, tg: TelegramClient, enabled: boolean): Promise<void> {
  if (cmd.args.length < 1) {
    await tg.sendMessage(String(cmd.chatId), `Usage: /${enabled ? 'enable' : 'disable'}source <id>`);
    return;
  }
  const target = cmd.args[0].trim();
  let src = await repo.getSource(target);
  if (!src) src = await repo.getSourceByChannelId(target);
  if (!src) {
    await tg.sendMessage(String(cmd.chatId), 'Source not found.');
    return;
  }
  await repo.setSourceEnabled(src.source_id, enabled);
  await tg.sendMessage(String(cmd.chatId), `${enabled ? '🟢' : '🔴'} Source ${src.display_name ?? src.telegram_channel_id} ${enabled ? 'enabled' : 'disabled'}.`);
}

async function status(repo: Repository, tg: TelegramClient, chatId: number): Promise<void> {
  const sources = await repo.listSources();
  const qlen = await repo.queueLength();
  const paused = (await repo.getSetting('paused')) === '1';
  const lines = sources.map((s) => `${s.enabled ? '🟢' : '🔴'} ${s.display_name ?? s.telegram_channel_id} → last=${s.last_processed_message_id}${s.last_error ? ' ⚠️' : ''}`);
  await tg.sendMessage(
    String(chatId),
    `*Status*\nSources: ${sources.length}\nQueue: ${qlen}\n${paused ? '⏸️ Paused' : '▶️ Running'}\n\n${lines.join('\n') || 'No sources.'}`,
    { parse_mode: 'Markdown' },
  );
}

async function queue(repo: Repository, tg: TelegramClient, chatId: number): Promise<void> {
  const items = await repo.listQueue(40);
  if (items.length === 0) {
    await tg.sendMessage(String(chatId), 'Queue is empty.');
    return;
  }
  const lines = items.map((i) => `${i.country} ${i.protocol} \`${i.config_hash.slice(0, 10)}\``);
  await tg.sendMessage(String(chatId), `*Queue (${items.length})*\n${lines.join('\n')}`, { parse_mode: 'Markdown' });
}

async function clearQueue(repo: Repository, tg: TelegramClient, chatId: number): Promise<void> {
  const n = await repo.clearQueue();
  await tg.sendMessage(String(chatId), `🧹 Cleared ${n} queue item(s).`);
}

async function showConfig(cfg: ReturnType<typeof loadConfig>, tg: TelegramClient, chatId: number): Promise<void> {
  const text = [
    '*Configuration*',
    `Destination: ${cfg.destinationChannel}`,
    `Publish interval: ${cfg.publishIntervalMinutes} min`,
    `Queue strategy: ${cfg.queueStrategy}`,
    `DNS resolver: ${cfg.dnsResolver}`,
    `Admins: ${cfg.adminUserIds.join(', ')}`,
  ].join('\n');
  await tg.sendMessage(String(chatId), text, { parse_mode: 'Markdown' });
}

async function stats(repo: Repository, tg: TelegramClient, chatId: number): Promise<void> {
  const s = await repo.getStats();
  const sources = await repo.listSources();
  const qlen = await repo.queueLength();
  const line = (k: string) => String(s[k] ?? 0);
  const text = [
    '*Statistics*',
    `Sources: ${sources.length}`,
    `Messages processed: ${line('messages_scanned')}`,
    `Configs extracted: ${line('configs_detected')}`,
    `NPV files: ${line('npv_files_detected')}`,
    `NPV decoded: ${line('npv_decoded')}`,
    `Duplicates: ${line('duplicates_detected')}`,
    `Rejected: ${line('configs_rejected')}`,
    `Published: ${line('configs_published')}`,
    `Publish failures: ${line('publishing_failures')}`,
    `Countries: ${line('countries_detected')}`,
    `Queue: ${qlen}`,
  ].join('\n');
  await tg.sendMessage(String(chatId), text, { parse_mode: 'Markdown' });
}

async function reprocess(cmd: IncomingCommand, repo: Repository, tg: TelegramClient): Promise<void> {
  if (cmd.args.length < 2) {
    await tg.sendMessage(String(cmd.chatId), 'Usage: /reprocess <source-id> <message-id>');
    return;
  }
  const [sourceId, msgIdStr] = cmd.args;
  const msgId = parseInt(msgIdStr, 10);
  if (!Number.isInteger(msgId)) {
    await tg.sendMessage(String(cmd.chatId), 'Invalid message id.');
    return;
  }
  const src = await repo.getSource(sourceId);
  if (!src) {
    await tg.sendMessage(String(cmd.chatId), 'Source not found.');
    return;
  }
  // Re-queue a reprocess by zeroing the ledger row so it will be re-ingested.
  await repo.resetSourcePosition(sourceId, msgId - 1);
  await tg.sendMessage(String(cmd.chatId), `🔄 Source ${sourceId} position reset to message ${msgId - 1}; it will be reprocessed from there.`);
}

async function reset(cmd: IncomingCommand, repo: Repository, tg: TelegramClient): Promise<void> {
  if (cmd.args.length < 1) {
    await tg.sendMessage(String(cmd.chatId), 'Usage: /reset <source-id>  (resets position to 0)');
    return;
  }
  const sourceId = cmd.args[0].trim();
  const src = await repo.getSource(sourceId);
  if (!src) {
    await tg.sendMessage(String(cmd.chatId), 'Source not found.');
    return;
  }
  await repo.resetSourcePosition(sourceId, 0);
  await tg.sendMessage(String(cmd.chatId), `♻️ Source ${sourceId} processing position reset to 0.`);
}

/** Parse a raw Telegram bot message into a CommandName + args. */
export function parseCommand(text: string | undefined): { command: CommandName; args: string[] } | null {
  if (!text || !text.startsWith('/')) return null;
  const parts = text.slice(1).trim().split(/\s+/);
  if (parts.length === 0) return null;
  const raw = (parts[0].split('@')[0] || '').toLowerCase() as CommandName;
  const valid: CommandName[] = [
    'start', 'help', 'addsource', 'removesource', 'sources', 'enablesource', 'disablesource',
    'status', 'queue', 'clearqueue', 'config', 'stats', 'reprocess', 'reset', 'pause', 'resume',
  ];
  if (!valid.includes(raw)) return null;
  return { command: raw, args: parts.slice(1) };
}
