import { AppError } from '../monitoring/errors';
import { createLogger } from '../monitoring/logging';

const log = createLogger('telegram');

const API_BASE = 'https://api.telegram.org';

interface TgResponse<T> {
  ok: boolean;
  result?: T;
  description?: string;
  error_code?: number;
  parameters?: {
    retry_after?: number;
    migrate_to_chat_id?: number;
  };
}

export interface TgMessage {
  message_id: number;
  chat?: { id: number; type: string; username?: string; title?: string };
  date?: number;
  text?: string;
  caption?: string;
  document?: {
    file_id: string;
    file_name?: string;
    mime_type?: string;
    file_size?: number;
  };
  media_group_id?: string;
  from?: { id: number; is_bot?: boolean; username?: string };
  sender_chat?: { id: number; username?: string; title?: string; type: string };
  channel_chat_created?: boolean;
}

export interface TgUpdate {
  update_id: number;
  message?: TgMessage;
  channel_post?: TgMessage;
  edited_message?: TgMessage;
  edited_channel_post?: TgMessage;
}

export interface TgFile {
  file_id: string;
  file_unique_id: string;
  file_size?: number;
  file_path?: string;
}

export interface SendMessageOptions {
  parse_mode?: 'HTML' | 'MarkdownV2' | 'Markdown';
  disable_web_page_preview?: boolean;
  disable_notification?: boolean;
  reply_to_message_id?: number;
}

/**
 * A lightweight, robust Telegram Bot API client.
 * - Global monotonic throttle (respects Telegram's ~30 msg/sec and channel limits)
 * - Retry-after / flood-wait handling with exponential backoff
 * - Categorized errors (retryable vs fatal)
 */
export class TelegramClient {
  private readonly token: string;
  private lastRequestAt = 0;
  private minGapMs = 40; // ~25 req/s conservative floor
  private floodUntil = 0; // epoch ms until flood wait clears

  constructor(token: string) {
    this.token = token;
  }

  /** Raw API call with throttle + retry + flood-wait. */
  async call<T>(method: string, params: Record<string, unknown>, retries = 4): Promise<T> {
    await this.throttle();

    const url = `${API_BASE}/bot${this.token}/${method}`;
    let attempt = 0;
    // eslint-disable-next-line no-constant-condition
    while (true) {
      attempt++;
      let resp: Response;
      try {
        resp = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(params),
        });
      } catch (e) {
        throw new AppError('telegram', `network error on ${method}`, {
          context: { method },
          retryable: true,
          cause: e,
        });
      }

      let body: TgResponse<T>;
      try {
        body = (await resp.json()) as TgResponse<T>;
      } catch (e) {
        throw new AppError('telegram', `non-JSON response on ${method}`, {
          context: { method, status: resp.status },
          cause: e,
        });
      }

      if (body.ok && body.result !== undefined) {
        this.lastRequestAt = Date.now();
        return body.result;
      }

      const errCode = body.error_code ?? resp.status;
      const retryAfter = body.parameters?.retry_after;

      // Flood wait: honor global Retry-After and back off.
      if (retryAfter) {
        this.floodUntil = Date.now() + retryAfter * 1000;
        log.warn('telegram_flood_wait', { method, retry_after: retryAfter });
        if (attempt >= retries) {
          throw new AppError('ratelimit', `flood wait on ${method} (${retryAfter}s)`, {
            context: { method, retry_after: retryAfter },
          });
        }
        await sleep(retryAfter * 1000 + 50);
        continue;
      }

      // 429 without retry_after, or transient server errors.
      if ((errCode === 429 || errCode >= 500) && attempt < retries) {
        const backoff = Math.min(60000, 200 * Math.pow(2, attempt));
        log.warn('telegram_transient_error', { method, errCode, backoff_ms: backoff });
        await sleep(backoff);
        continue;
      }

      // Fatal (400, 403, 404, ...). Categorize.
      const isRetryable = errCode === 429 || errCode >= 500;
      throw new AppError('telegram', body.description ?? `Telegram error ${errCode}`, {
        context: { method, error_code: errCode },
        retryable: isRetryable,
      });
    }
  }

  /** Monotonic throttle to respect global request-rate limits. */
  private async throttle(): Promise<void> {
    const now = Date.now();
    if (now < this.floodUntil) {
      await sleep(this.floodUntil - now);
    }
    const target = this.lastRequestAt + this.minGapMs;
    if (now < target) {
      await sleep(target - now);
    }
  }

  // -------------------------------------------------------------------------
  // Convenience methods
  // -------------------------------------------------------------------------

  getUpdates(offset: number, limit = 100, timeout = 25): Promise<TgUpdate[]> {
    return this.call<TgUpdate[]>('getUpdates', {
      offset,
      limit,
      timeout,
      allowed_updates: JSON.stringify(['message', 'channel_post', 'edited_message', 'edited_channel_post']),
    });
  }

  getFile(fileId: string): Promise<TgFile> {
    return this.call<TgFile>('getFile', { file_id: fileId });
  }

  sendMessage(chatId: string, text: string, opts: SendMessageOptions = {}): Promise<TgMessage> {
    return this.call<TgMessage>('sendMessage', {
      chat_id: chatId,
      text,
      ...opts,
    });
  }

  async downloadFile(filePath: string, maxBytes: number): Promise<Uint8Array> {
    const url = `${API_BASE}/file/bot${this.token}/${filePath}`;
    const resp = await fetch(url);
    if (!resp.ok) {
      throw new AppError('download', `file download failed (${resp.status})`, {
        context: { file_path: filePath, status: resp.status },
        retryable: resp.status >= 500,
      });
    }
    const len = Number(resp.headers.get('content-length') ?? '0');
    if (len && len > maxBytes) {
      throw new AppError('npv', `file too large (${len} > ${maxBytes})`, {
        context: { max: maxBytes, actual: len },
      });
    }
    const buf = new Uint8Array(await resp.arrayBuffer());
    if (buf.byteLength > maxBytes) {
      throw new AppError('npv', `file too large (${buf.byteLength} > ${maxBytes})`, {
        context: { max: maxBytes, actual: buf.byteLength },
      });
    }
    return buf;
  }

  setWebhook(url: string, secretToken?: string): Promise<boolean> {
    const params: Record<string, unknown> = { url };
    if (secretToken) params.secret_token = secretToken;
    return this.call<boolean>('setWebhook', params).catch(() => false);
  }

  deleteWebhook(): Promise<boolean> {
    return this.call<boolean>('deleteWebhook', { drop_pending_updates: false }).catch(() => false);
  }

  getMe(): Promise<{ id: number; username?: string }> {
    return this.call<{ id: number; username?: string }>('getMe', {});
  }

  editMessageText(chatId: string, messageId: number, text: string, opts: SendMessageOptions = {}): Promise<TgMessage> {
    return this.call<TgMessage>('editMessageText', {
      chat_id: chatId,
      message_id: messageId,
      text,
      ...opts,
    });
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

export function botFileUrl(token: string, filePath: string): string {
  return `${API_BASE}/file/bot${token}/${filePath}`;
}
