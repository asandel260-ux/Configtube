// Post formatting + Telegram HTML/MarkdownV2 escaping.
//
// Security-critical: config strings are arbitrary attacker-controlled text and
// MUST be escaped before being embedded in Telegram formatting, or a config
// containing `</b>` / `<i>` / backticks could break the message layout.

import type { CountryCode } from '../types';

/** Convert an ISO 3166-1 alpha-2 code (lowercase) to a flag emoji. */
export function countryFlag(code: CountryCode): string {
  if (!code || code === 'xx' || code.length !== 2) return '🌐';
  const a = code.charCodeAt(0) - 97 + 0x1f1e6;
  const b = code.charCodeAt(1) - 97 + 0x1f1e6;
  if (a < 0x1f1e6 || b < 0x1f1e6) return '🌐';
  return String.fromCodePoint(a, b);
}

/** Escape a string for Telegram HTML parse mode. */
export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;');
}

/** Escape a string for Telegram MarkdownV2 parse mode. */
export function escapeMarkdownV2(s: string): string {
  return s.replace(/([_*[\]()~`>#+\-=|{}.!\\])/g, '\\$1');
}

export interface PostTemplate {
  flag?: boolean;
  countryCode?: boolean;
  monoConfig?: boolean;
  attribution?: boolean;
}

/**
 * Build the standardized post body (HTML parse mode).
 *
 * Layout:
 *   🇫🇷 fr
 *   <code>vless://...</code>
 *   fr 🇫🇷 | https://t.me/channel/12345
 */
export function buildPost(
  encodedConfig: string,
  country: CountryCode,
  sourceUrl: string,
  _template?: PostTemplate,
): { text: string; parse_mode: 'HTML' } {
  const flag = countryFlag(country);
  const lines: string[] = [];

  lines.push(`${flag} ${country}`);
  lines.push(`<code>${escapeHtml(encodedConfig)}</code>`);

  // Footer: flag + code + source link (links directly to the source message).
  const link = escapeHtml(sourceUrl);
  lines.push(`${flag} ${country} | <a href="${link}">Source</a>`);

  return { text: lines.join('\n'), parse_mode: 'HTML' };
}

/** Build a plain-text fallback (used in the admin panel preview). */
export function buildPostPlain(encodedConfig: string, country: CountryCode, sourceUrl: string): string {
  const flag = countryFlag(country);
  return `${flag} ${country}\n${encodedConfig}\n${flag} ${country} | ${sourceUrl}`;
}
