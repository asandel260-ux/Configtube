// Source listener: detect NEW messages from configured source channels.
//
// Two complementary paths:
//   1. Webhook (primary): Telegram pushes updates to our /webhook endpoint.
//   2. Cron (fallback/heartbeat): poll getUpdates with a persisted offset cursor
//      (the bot's own update stream, for channels the bot is an admin of).
//
// Both funnel into processIncomingMessage which is fully idempotent via the
// claimSourceMessage ledger (a message is processed exactly once, even if the
// webhook is retried or the cron overlaps).

import type { Env, Source, SourceMessage } from '../types';
import { Repository } from '../database/repository';
import { processSourceMessage, type ProcessorOptions } from '../pipeline/processor';
import { createLogger } from '../monitoring/logging';
import { describeError } from '../monitoring/errors';
import type { TgMessage, TgUpdate } from './client';

const log = createLogger('source_listener');

/** Extract a normalized SourceMessage from any Telegram update/message object. */
export function toSourceMessage(channelId: string, msg: TgMessage): SourceMessage {
  return {
    channel_id: channelId,
    message_id: msg.message_id,
    timestamp: msg.date,
    text: msg.text,
    caption: msg.caption,
    documents: msg.document
      ? [
          {
            file_id: msg.document.file_id,
            name: msg.document.file_name,
            mime_type: msg.document.mime_type,
            size: msg.document.file_size,
          },
        ]
      : undefined,
  };
}

/**
 * Determine the channel id from an update. Returns null if the update does not
 * correspond to one of our monitored sources.
 */
export async function resolveChannel(repo: Repository, update: TgUpdate): Promise<{ source: Source; channelId: string; message: TgMessage } | null> {
  const msg = update.message ?? update.channel_post ?? update.edited_message ?? update.edited_channel_post;
  if (!msg) return null;

  // Telegram channel messages carry sender_chat or a chat with a negative id.
  const chat = msg.chat ?? msg.sender_chat;
  if (!chat) return null;

  // Normalize: for channels, the id is negative; username may be present.
  const candidates = [
    chat.username ? `@${chat.username}` : null,
    chat.id ? String(chat.id) : null,
  ].filter((c): c is string => !!c);

  for (const cid of candidates) {
    const source = await repo.getSourceByChannelId(cid);
    if (source && source.enabled) {
      return { source, channelId: cid, message: msg };
    }
    // Also match by numeric-only id (cheat for `-100...`).
    const numeric = String(chat.id);
    if (cid !== numeric) {
      const src2 = await repo.getSourceByChannelId(numeric);
      if (src2 && src2.enabled) return { source: src2, channelId: numeric, message: msg };
    }
  }
  return null;
}

export interface ListenerOptions {
  processor: ProcessorOptions;
}

/**
 * Process an incoming update (from webhook). Idempotent.
 */
export async function handleIncomingUpdate(
  update: TgUpdate,
  repo: Repository,
  env: Env,
  opts: ListenerOptions,
): Promise<{ processed: boolean; reason?: string }> {
  const resolved = await resolveChannel(repo, update);
  if (!resolved) return { processed: false, reason: 'not_a_monitored_source' };

  const { source, channelId, message } = resolved;

  // Only process messages NEWER than last_processed_message_id.
  if (message.message_id <= source.last_processed_message_id) {
    return { processed: false, reason: 'old_or_duplicate_message' };
  }

  return processAndAdvance(source, channelId, message, repo, env, opts.processor);
}

/**
 * Claim + process + advance. Shared by webhook and cron.
 * Idempotent: claimSourceMessage ensures single processing.
 */
async function processAndAdvance(
  source: Source,
  channelId: string,
  message: TgMessage,
  repo: Repository,
  env: Env,
  processor: ProcessorOptions,
): Promise<{ processed: boolean; reason?: string }> {
  const claim = await repo.claimSourceMessage(channelId, message.message_id);
  if (claim === 'already') {
    return { processed: false, reason: 'already_processed' };
  }

  await repo.incrementStat('messages_scanned');

  const sourceMessage = toSourceMessage(channelId, message);
  try {
    const result = await processSourceMessage(sourceMessage, repo, env, processor);
    await repo.markSourceMessageProcessed(channelId, message.message_id, {
      text: message.text,
      caption: message.caption,
      documents: message.document ? JSON.stringify([message.document]) : undefined,
      raw_update: JSON.stringify(message),
      configs_found: result.configsFound,
    });
    log.info('source_message_received', { source: source.source_id, message_id: message.message_id, configs: result.configsFound });
  } catch (e) {
    // Record the message as processed (so we don't loop) and log the error.
    await repo.markSourceMessageProcessed(channelId, message.message_id, {
      text: message.text,
      caption: message.caption,
      documents: message.document ? JSON.stringify([message.document]) : undefined,
      raw_update: JSON.stringify(message),
      configs_found: 0,
    });
    await repo.logError(describeError(e).category, describeError(e).message, { source: source.source_id, message_id: message.message_id });
    await repo.setSourceError(source.source_id, describeError(e).message);
    log.error('source_message_processing_error', { source: source.source_id, message_id: message.message_id, error: describeError(e).message });
  }

  // Advance the high-water mark.
  await repo.updateLastProcessed(source.source_id, message.message_id);
  return { processed: true };
}

/**
 * Cron fallback: poll the bot's own update stream (getUpdates) for messages in
 * monitored channels. Uses a persisted offset cursor in settings.
 */
export async function pollUpdates(repo: Repository, env: Env, opts: ListenerOptions, tg: {
  getUpdates: (offset: number, limit?: number, timeout?: number) => Promise<TgUpdate[]>;
}): Promise<number> {
  const raw = (await repo.getSetting('last_update_id')) ?? '0';
  let offset = parseInt(raw, 10) || 0;
  let processed = 0;

  const updates = await tg.getUpdates(offset, 100, 2);
  for (const u of updates) {
    if (u.update_id >= offset) offset = u.update_id + 1;
    const r = await handleIncomingUpdate(u, repo, env, opts);
    if (r.processed) processed++;
  }
  await repo.setSetting('last_update_id', String(offset));
  if (processed > 0) log.info('cron_processed_messages', { count: processed });
  return processed;
}
