// Canonical cross-module type definitions.

/** ISO 3166-1 alpha-2 country code, lowercase; 'xx' means UNKNOWN. */
export type CountryCode = string;

/** A single extracted V2Ray/Xray configuration in canonical form. */
export interface V2rayConfig {
  protocol: string; // vmess | vless | trojan | ss | ssr | ...
  server: string; // hostname or IP (as given)
  port?: number | null;
  uuid?: string;
  password?: string;
  security?: string; // e.g. auto | aes-128-gcm | chacha20-poly1305
  network?: string; // tcp | ws | grpc | httpupgrade | quic | kcp | ...
  tls?: string; // none | tls | reality
  sni?: string;
  host?: string; // ws host / http host
  path?: string;
  serviceName?: string; // grpc serviceName
  flow?: string; // xtls-rprx-vision etc.
  publicKey?: string; // reality public key
  shortId?: string; // reality shortId
  fingerprint?: string; // tls fingerprint (firefox/chrome/...)
  transport?: string; // generic transport hint
  method?: string; // ss/ssr cipher
  tag?: string; // ps/remark
  raw?: string; // original uri string (for display/export)
}

/** Attribution metadata attached to every extracted config. */
export interface ConfigAttribution {
  source_channel: string; // telegram channel id/username
  source_message_id: number;
  source_message_url: string; // t.me/<chan>/<msgid>
  first_seen: string; // ISO timestamp
}

/** A normalized + fingerprinted config ready for dedup/enqueue. */
export interface ProcessedConfig {
  id: string;
  config_hash: string;
  config: V2rayConfig;
  normalized: string;
  country: CountryCode;
  attribution: ConfigAttribution;
  encoded_config: string; // final copy-friendly string to publish
}

/** A source-channel record. */
export interface Source {
  source_id: string;
  telegram_channel_id: string;
  username: string | null;
  display_name: string | null;
  enabled: boolean;
  last_processed_message_id: number;
  added_at: string;
  updated_at: string;
  last_error: string | null;
}

/** A raw Telegram message the bot ingests. */
export interface SourceMessage {
  channel_id: string;
  message_id: number;
  timestamp?: number;
  text?: string;
  caption?: string;
  media?: unknown;
  documents?: FileRef[];
}

export interface FileRef {
  file_id: string;
  name?: string;
  mime_type?: string;
  size?: number;
}

/** Queue ordering strategies. */
export type QueueStrategy =
  | 'chronological'
  | 'source-order'
  | 'country-balanced'
  | 'random'
  | 'newest-first'
  | 'priority-source';

export interface Env {
  DB: D1Database;
  PUBLISHER_QUEUE: DurableObjectNamespace;
  NPV_DECODER: DurableObjectNamespace;
  TELEGRAM_BOT_TOKEN?: string;
  WEBHOOK_SECRET?: string;
  SET_WEBHOOK_URL?: string;
  ADMIN_USER_IDS?: string;
  DESTINATION_CHANNEL?: string;
  ADMIN_PANEL_PASSWORD?: string;
  ADMIN_PANEL_PATH?: string;
  PUBLISH_INTERVAL_MINUTES?: string;
  QUEUE_STRATEGY?: string;
  DNS_RESOLVER?: string;
  DNS_TIMEOUT_MS?: string;
  NPV_MAX_FILE_BYTES?: string;
  NPV_DECODE_TIMEOUT_MS?: string;
  // Optional GeoIP database sources (see README "GeoIP country database"):
  GEOIP_JSON?: string; // ranges JSON from scripts/build-geoip.mjs
  GEOIP_CSV?: string; // raw ip2c country.csv text
  GEOIP?: Uint8Array; // asset binding (JSON or CSV bytes)
}
