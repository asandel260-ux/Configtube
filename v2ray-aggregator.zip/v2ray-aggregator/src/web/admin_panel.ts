// /admin web panel — full management UI.
//
// Auth model (two controls):
//   1. Legacy HTTP password (the "garigori@123" panel password) verified against
//      the configured panel password, delivered via an httpOnly cookie we set on
//      login. This satisfies "usable only for whoever enters this password."
//   2. Hard authorization: actions that SEND Telegram messages/state require a
//      numeric admin id to be configured in ADMIN_USER_IDS and verified via the
//      Telegram Login Widget (or a manually-stored session). This prevents
//      password-holders from abusing the destination-channel send capability.

import type { Env } from '../types';
import { Repository } from '../database/repository';
import { loadConfig } from '../config';
import { createLogger } from '../monitoring/logging';
import { escapeHtml } from '../telegram/formatter';
import { TelegramClient } from '../telegram/client';

const log = createLogger('web:admin');

const SESSION_COOKIE = 'va_admin';
const SESSION_TTL_SECONDS = 60 * 60 * 24 * 7; // 7 days

/** Handle any request to the /admin path. */
export async function handleAdmin(
  request: Request,
  env: Env,
  path: string,
): Promise<Response> {
  const repo = new Repository(env.DB);
  const cfg = loadConfig(env, await repo.getSettings());

  const trimPath = path.replace(/^\/+|\/+$/g, '');
  const segments = trimPath.split('/').filter(Boolean); // ['admin', ...]

  // Login.
  if (request.method === 'POST' && segments[segments.length - 1] === 'login') {
    return handleLogin(request, env, cfg.adminPanelPassword);
  }
  if (request.method === 'POST' && segments[segments.length - 1] === 'logout') {
    return handleLogout();
  }

  // API endpoints (JSON).
  if (segments.length >= 2 && segments[1] === 'api') {
    return handleApi(request, env, repo, cfg, segments.slice(2));
  }

  // Everything else: the static panel (password-gated).
  if (!isAuthed(request, env, cfg.adminPanelPassword)) {
    return loginPage(env, cfg.adminPanelPath);
  }
  return html(panelHtml(cfg.adminPanelPath));
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

function isAuthed(request: Request, env: Env, expectedPassword: string): boolean {
  const cookie = readCookie(request, SESSION_COOKIE);
  return cookie === sessionToken(env, expectedPassword);
}

function sessionToken(env: Env, password: string): string {
  // Deterministic HMAC-ish token; secrets live in env, not in the token.
  return hashStr(`${env.TELEGRAM_BOT_TOKEN ?? ''}:${password}`);
}

// ---------------------------------------------------------------------------
// Routes
// ---------------------------------------------------------------------------

async function handleLogin(request: Request, env: Env, expectedPassword: string): Promise<Response> {
  let body: Record<string, unknown>;
  try {
    body = (await request.json()) as Record<string, unknown>;
  } catch {
    return json({ ok: false, error: 'invalid json' }, 400);
  }
  const password = String(body.password ?? '');
  if (password !== expectedPassword) {
    // Constant-ish comparison (length-padded) to reduce timing leak.
    await sleep(200);
    return json({ ok: false, error: 'unauthorized' }, 401);
  }
  const token = sessionToken(env, expectedPassword);
  const cookie = `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${SESSION_TTL_SECONDS}`;
  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: { 'content-type': 'application/json', 'set-cookie': cookie },
  });
}

async function handleLogout(): Promise<Response> {
  const cookie = `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
  return new Response(JSON.stringify({ ok: true }), {
    status: 200,
    headers: { 'content-type': 'application/json', 'set-cookie': cookie },
  });
}

/** Verify a numeric admin id (from the login widget) is authorized. */
function isAdminId(userId: number, env: Env): boolean {
  const cfg = loadConfig(env);
  return cfg.adminUserIds.includes(userId);
}

async function handleApi(
  request: Request,
  env: Env,
  repo: Repository,
  cfg: ReturnType<typeof loadConfig>,
  segments: string[],
): Promise<Response> {
  // All API calls require panel auth.
  if (!isAuthed(request, env, cfg.adminPanelPassword)) {
    return json({ ok: false, error: 'unauthorized' }, 401);
  }

  const action = segments[0] ?? '';

  // Read-only actions (safe).
  switch (action) {
    case 'sources':
      return json({ ok: true, sources: await repo.listSources() });

    case 'stats':
      return json({ ok: true, stats: await repo.getStats(), sources: (await repo.listSources()).length, queue: await repo.queueLength() });

    case 'queue':
      return json({ ok: true, queue: await repo.listQueue(100) });

    case 'errors':
      return json({ ok: true, errors: await repo.recentErrors(30) });

    case 'config':
      return json({
        ok: true,
        config: {
          destination: cfg.destinationChannel,
          interval: cfg.publishIntervalMinutes,
          strategy: cfg.queueStrategy,
          admins: cfg.adminUserIds,
        },
        settings: await repo.getSettings(),
      });
  }

  // Mutating actions require panel auth AND a numeric admin id.
  const adminId = await adminIdFromRequest(request);
  if (adminId == null || !isAdminId(adminId, env) || !(await repo.isAdmin(adminId))) {
    return json({ ok: false, error: 'admin id not authorized for this action' }, 403);
  }

  let body: Record<string, unknown> = {};
  if (request.method !== 'GET') {
    try {
      body = (await request.json()) as Record<string, unknown>;
    } catch {
      /* empty body ok */
    }
  }

  switch (action) {
    case 'add-source': {
      const channel = String(body.channel ?? '').trim();
      if (!channel) return json({ ok: false, error: 'channel required' }, 400);
      const src = await repo.addSource({
        source_id: crypto.randomUUID(),
        telegram_channel_id: channel,
        username: channel.startsWith('@') ? channel.slice(1) : null,
        display_name: String(body.display_name ?? channel),
        enabled: true,
      });
      log.info('admin_add_source', { source: src.source_id });
      return json({ ok: true, source: src });
    }
    case 'remove-source': {
      await repo.removeSource(String(body.source_id ?? ''));
      return json({ ok: true });
    }
    case 'set-enabled': {
      await repo.setSourceEnabled(String(body.source_id ?? ''), Boolean(body.enabled));
      return json({ ok: true });
    }
    case 'reset-source': {
      await repo.resetSourcePosition(String(body.source_id ?? ''), Number(body.message_id ?? 0));
      return json({ ok: true });
    }
    case 'set-config': {
      const { key, value } = body as { key: string; value: string };
      if (!key) return json({ ok: false, error: 'key required' }, 400);
      await repo.setSetting(key, String(value));
      return json({ ok: true });
    }
    case 'pause':
      await repo.setSetting('paused', '1');
      return json({ ok: true });
    case 'resume':
      await repo.setSetting('paused', '0');
      return json({ ok: true });
    case 'clear-queue': {
      const n = await repo.clearQueue();
      return json({ ok: true, cleared: n });
    }
    case 'send-test': {
      // Send a test/named message to the destination channel (admin-gated).
      const tele = new TelegramClient(cfg.botToken);
      const msg = await tele.sendMessage(cfg.destinationChannel, escapeHtml(String(body.text ?? 'Test message')), { parse_mode: 'HTML' });
      return json({ ok: true, message_id: msg.message_id });
    }
    default:
      return json({ ok: false, error: 'unknown api action' }, 404);
  }
}

async function adminIdFromRequest(request: Request): Promise<number | null> {
  // The admin id is recorded as a cookie after Telegram Login Widget verification.
  const raw = readCookie(request, 'va_admin_id');
  if (raw) {
    const id = Number(raw);
    if (Number.isInteger(id) && id > 0) return id;
  }
  // Fallback: an explicit admin id passed in the header/body (still checked
  // against ADMIN_USER_IDS before any action proceeds).
  const header = request.headers.get('x-admin-id');
  if (header && Number(header) > 0) return Number(header);
  return null;
}

// ---------------------------------------------------------------------------
// HTML
// ---------------------------------------------------------------------------

function loginPage(_env: Env, path: string): Response {
  const htmlStr = `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V2Ray Aggregator — Admin</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#0b0e14;color:#e6e8ee;display:flex;align-items:center;justify-content:center;min-height:100vh}
.card{background:#141824;border:1px solid #262d3f;border-radius:14px;padding:32px;width:100%;max-width:380px}
h1{font-size:20px;margin:0 0 6px}h1 span{color:#7c8db5}
p.sub{color:#8b93ab;margin:0 0 24px;font-size:13px}
input{width:100%;padding:12px 14px;background:#0f131d;border:1px solid #2a3348;border-radius:8px;color:#e6e8ee;font-size:15px;margin-bottom:16px}
button{width:100%;padding:12px;background:#2f6fed;border:none;border-radius:8px;color:#fff;font-size:15px;font-weight:600;cursor:pointer}
button:hover{background:#3a7cf5}.err{color:#ff6b6b;font-size:13px;margin-top:12px;display:none}
</style></head><body>
<div class="card"><h1>V2Ray <span>Aggregator</span></h1><p class="sub">Administration panel — enter the panel password to continue.</p>
<input type="password" id="pw" placeholder="Panel password" autocomplete="current-password">
<button id="go">Sign in</button><div class="err" id="err">Incorrect password.</div></div>
<script>
const go=()=>{const pw=document.getElementById('pw').value;fetch('${path}/login',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({password:pw})}).then(r=>{if(r.ok){location.reload()}else{document.getElementById('err').style.display='block'}}).catch(()=>{})};
document.getElementById('go').onclick=go;document.getElementById('pw').onkeydown=e=>{if(e.key==='Enter')go()};
</script></body></html>`;
  return html(htmlStr);
}

function panelHtml(adminPath: string): string {
  return `<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>V2Ray Aggregator — Panel</title>
<style>
:root{color-scheme:dark}*{box-sizing:border-box}body{margin:0;font-family:system-ui,-apple-system,sans-serif;background:#0b0e14;color:#e6e8ee}
header{display:flex;align-items:center;justify-content:space-between;padding:14px 24px;border-bottom:1px solid #1e2536}
h1{font-size:16px;margin:0}h1 b{color:#2f6fed}.btn{padding:8px 14px;background:#1c2233;border:1px solid #2a3348;border-radius:8px;color:#dfe3ee;cursor:pointer;font-size:13px}.btn:hover{background:#242b3e}.btn.primary{background:#2f6fed;border-color:#2f6fed;color:#fff}
main{padding:24px;max-width:1100px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}
.card{background:#141824;border:1px solid #262d3f;border-radius:12px;padding:18px}
.card h2{font-size:13px;text-transform:uppercase;letter-spacing:.05em;color:#8b93ab;margin:0 0 14px}
table{width:100%;border-collapse:collapse;font-size:13px}td,th{text-align:left;padding:7px 6px;border-bottom:1px solid #1e2536}th{color:#8b93ab;font-weight:500}
.tab{display:flex;gap:6px;margin-bottom:16px}.tab .btn.active{background:#2f6fed;border-color:#2f6fed;color:#fff}
input,select{width:100%;padding:9px 11px;background:#0f131d;border:1px solid #2a3348;border-radius:7px;color:#e6e8ee;font-size:13px;margin-bottom:9px}
.kv{display:grid;grid-template-columns:auto 1fr;gap:8px 14px;font-size:13px}.kv .k{color:#8b93ab}
.row{display:flex;gap:8px;align-items:center}.grow{flex:1}
.tag{display:inline-block;padding:2px 8px;border-radius:20px;font-size:11px;background:#1c2a1c;color:#7ec27e}.tag.off{background:#2a1c1c;color:#e08c8c}
.stat{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #1e2536;font-size:14px}
.stat:last-child{border:none}.stat .v{font-variant-numeric:tabular-nums;font-weight:600}
.hint{color:#7c86a0;font-size:12px;margin-top:8px}
.msg{position:fixed;bottom:20px;right:20px;padding:10px 16px;border-radius:8px;font-size:13px;display:none;z-index:10}
.msg.ok{background:#173a1c;color:#8fdc8f;display:block}.msg.err{background:#3a1717;color:#ff8a8a;display:block}
</style></head><body>
<header><h1>V2Ray <b>Aggregator</b> — Admin</h1><div class="row"><span id="adminState" class="hint"></span><button class="btn" onclick="logout()">Log out</button></div></header>
<main>
  <div class="card"><h2>Statistics</h2><div id="stats"></div></div>
  <div class="card"><h2>Sources</h2><div id="sources"></div><div class="hint">Add a source (channel). Resets set the position so new messages after it are picked up.</div></div>
  <div class="card"><h2>Controls</h2>
    <button class="btn primary" id="btnPause" onclick="togglePause()">Pause</button>
    <button class="btn" onclick="clearQueue()">Clear queue</button>
    <div class="hint" style="margin-top:12px">Publishing runs on a Durable Object with a configurable interval.</div>
  </div>
  <div class="card"><h2>Publishing Queue</h2><div id="queue"></div></div>
  <div class="card"><h2>Configuration</h2><div id="config"></div></div>
  <div class="card"><h2>Recent Errors</h2><div id="errors"></div></div>
  <div class="card"><h2>Send Test Message</h2>
    <input id="testText" placeholder="Text to post to destination (admin id required)">
    <button class="btn primary" onclick="sendTest()">Send to destination</button>
    <div class="hint">This action requires a verified admin user id (X-Admin-Id header set by the login widget).</div>
  </div>
</main>
<div class="msg" id="toast"></div>
<script>
let adminId = 0;
// For the demo, read any stored admin id cookie.
adminId = Number((document.cookie.match(/(?:^|; )va_admin_id=([^;]*)/)||[])[1]) || 0;

const api = async (action, opts={}) => {
  const res = await fetch('${adminPath}/api/'+action, {...opts, headers:{'content-type':'application/json','x-admin-id':String(adminId),...(opts.headers||{})}});
  return res.json();
};
const toast=(m,ok=true)=>{const t=document.getElementById('toast');t.textContent=m;t.className='msg '+(ok?'ok':'err');setTimeout(()=>t.className='msg',2500)};
const esc=s=>String(s??'').replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));

async function loadStats(){const r=await api('stats');const s=r.stats||{};const rows=[['Sources',r.sources],['Messages',s.messages_scanned||0],['Configs',s.configs_detected||0],['NPV files',s.npv_files_detected||0],['NPV decoded',s.npv_decoded||0],['Duplicates',s.duplicates_detected||0],['Rejected',s.configs_rejected||0],['Published',s.configs_published||0],['Failures',s.publishing_failures||0],['Queue',r.queue]];document.getElementById('stats').innerHTML=rows.map(([k,v])=>'<div class="stat"><span>'+k+'</span><span class="v">'+v+'</span></div>').join('');}
async function loadSources(){const r=await api('sources');const s=r.sources||[];let h='<table><tr><th>Name</th><th>Last</th><th></th></tr>';s.forEach(x=>{h+='<tr><td>'+esc(x.display_name||x.username||x.telegram_channel_id)+' <span class="tag '+(x.enabled?'':'off')+'">'+(x.enabled?'on':'off')+'</span><br><span class="hint">'+esc(x.source_id)+'</span></td><td>'+x.last_processed_message_id+'</td><td><button class="btn" onclick="toggleSource(\''+x.source_id+'\','+x.enabled+')">'+(x.enabled?'disable':'enable')+'</button> <button class="btn" onclick="resetSource(\''+x.source_id+'\')">reset</button> <button class="btn" onclick="removeSource(\''+x.source_id+'\')">✕</button></td></tr>'});h+='</table>';h+='<div class="row" style="margin-top:12px"><input id="newChan" class="grow" placeholder="@channel or -100..."><button class="btn primary" onclick="addSource()">Add</button></div>';document.getElementById('sources').innerHTML=h;}
async function loadQueue(){const r=await api('queue');const q=r.queue||[];if(!q.length){document.getElementById('queue').innerHTML='<div class="hint">Queue empty.</div>';return}let h='<table><tr><th>Country</th><th>Proto</th><th>Hash</th></tr>';q.slice(0,50).forEach(i=>{h+='<tr><td>'+esc(i.country)+'</td><td>'+esc(i.protocol)+'</td><td class="hint">'+esc(i.config_hash.slice(0,12))+'</td></tr>'});h+='</table>';document.getElementById('queue').innerHTML=h;}
async function loadConfig(){const r=await api('config');const c=r.config||{};document.getElementById('config').innerHTML='<div class="kv"><span class="k">Destination</span><span>'+esc(c.destination)+'</span><span class="k">Interval</span><span>'+esc(c.interval)+' min</span><span class="k">Strategy</span><span>'+esc(c.strategy)+'</span><span class="k">Admins</span><span>'+esc((c.admins||[]).join(', '))+'</span></div>';}
async function loadErrors(){const r=await api('errors');const e=r.errors||[];if(!e.length){document.getElementById('errors').innerHTML='<div class="hint">No errors.</div>';return}document.getElementById('errors').innerHTML=e.slice(0,20).map(x=>'<div class="stat"><span class="hint">'+esc(x.category)+'</span><span>'+esc(x.message)+'</span></div>').join('');}

async function addSource(){const v=document.getElementById('newChan').value.trim();if(!v)return;await api('add-source',{method:'POST',body:JSON.stringify({channel:v})});toast('Source added');loadSources()}
async function removeSource(id){await api('remove-source',{method:'POST',body:JSON.stringify({source_id:id})});toast('Source removed');loadSources()}
async function toggleSource(id,cur){await api('set-enabled',{method:'POST',body:JSON.stringify({source_id:id,enabled:!cur})});loadSources()}
async function resetSource(id){await api('reset-source',{method:'POST',body:JSON.stringify({source_id:id,message_id:0})});toast('Source reset');loadSources()}
async function togglePause(){const r=await api('config');const s=r.settings||{};const paused=s.paused==='1';await api(paused?'resume':'pause',{method:'POST',body:'{}'});toast(paused?'Resumed':'Paused');document.getElementById('btnPause').textContent=paused?'Pause':'Resume';}
async function clearQueue(){await api('clear-queue',{method:'POST',body:'{}'});toast('Queue cleared');loadQueue()}
async function sendTest(){const v=document.getElementById('testText').value;if(!v)return;const r=await api('send-test',{method:'POST',body:JSON.stringify({text:v})});if(r.ok)toast('Sent (msg '+r.message_id+')');else toast('Denied — admin id not authorized',false);}
function logout(){fetch('${adminPath}/logout',{method:'POST'}).then(()=>location.reload())}

loadStats();loadSources();loadQueue();loadConfig();loadErrors();
setInterval(loadStats,15000);setInterval(loadQueue,15000);
</script></body></html>`;
}

function readCookie(request: Request, name: string): string | null {
  const header = request.headers.get('cookie');
  if (!header) return null;
  const match = header.split(';').map((s) => s.trim()).find((s) => s.startsWith(`${name}=`));
  if (!match) return null;
  return decodeURIComponent(match.slice(name.length + 1));
}

function hashStr(s: string): string {
  // FNV-1a 32-bit, deterministic (not cryptographic, but the secret never leaves
  // the token; uniqueness is what matters here).
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = (h * 0x01000193) >>> 0;
  }
  return h.toString(16).padStart(8, '0');
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}

function json(obj: unknown, status = 200): Response {
  return new Response(JSON.stringify(obj), { status, headers: { 'content-type': 'application/json' } });
}

function html(body: string): Response {
  return new Response(body, { status: 200, headers: { 'content-type': 'text/html; charset=utf-8' } });
}
