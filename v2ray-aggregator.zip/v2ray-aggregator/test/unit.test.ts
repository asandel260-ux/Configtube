// Pure-function unit tests. Validates the correctness-critical, attacker-facing
// logic. Run with `npx vitest run` (or `node --experimental-strip-types`).

import { describe, it, expect } from 'vitest';
import { extractAllConfigUris, extractUris } from '../src/extraction/text_extractor';
import { parseUri } from '../src/extraction/uri_parser';
import { canonicalize, normalizeHost, normalizeIpv6 } from '../src/config/normalizer';
import { validateConfig } from '../src/config/validator';
import { fingerprint, dedupClassify } from '../src/config/fingerprint';
import { countryFlag, escapeHtml, escapeMarkdownV2, buildPostPlain } from '../src/telegram/formatter';
import { decodeNpv } from '../src/extraction/npv/decoder';
import { ipv4ToBigInt, ipv6ToBigInt, ipToBigInt } from '../src/geo/ipgeo';
import { isReservedOrPrivate } from '../src/geo/reserved';
import { computeSortKey } from '../src/queue/strategies';

describe('text extractor', () => {
  it('extracts vless + vmess from mixed text', () => {
    const text = 'hello check vless://abc@server.com:443?type=ws&security=tls and also vmess://eyJhZGQiOiIxLjIuMy40In0=';
    const uris = extractUris(text);
    expect(uris.length).toBe(2);
    expect(uris[0].scheme).toBe('vless');
    expect(uris[1].scheme).toBe('vmess');
  });

  it('does not confuse vless:// with the trailing ss:// substring', () => {
    const uris = extractUris('vless://uuid@host.com:443');
    expect(uris.length).toBe(1);
    expect(uris[0].scheme).toBe('vless');
  });

  it('deduplicates within a message (16 lines → 15 unique)', () => {
    const parts = Array.from({ length: 15 }, (_, i) => `vless://u${i}@h${i}.com:443`);
    const text = parts.join('\n') + '\n' + parts[0];
    expect(extractUris(text).length).toBe(15);
  });

  it('extracts from markdown/code fences', () => {
    const text = '```\n<code>trojan://pw@server.net:443#us</code>\n```';
    const uris = extractAllConfigUris(text);
    expect(uris.length).toBeGreaterThanOrEqual(1);
    expect(uris[0].scheme).toBe('trojan');
  });
});

describe('uri parser', () => {
  it('parses vless', () => {
    const c = parseUri('vless://550e8400-e29b-41d4-a716-446655440000@example.com:443?type=ws&security=tls&sni=example.com#tag');
    expect(c.protocol).toBe('vless');
    expect(c.uuid).toBe('550e8400-e29b-41d4-a716-446655440000');
    expect(c.server).toBe('example.com');
    expect(c.port).toBe(443);
    expect(c.network).toBe('ws');
    expect(c.security).toBe('tls');
  });

  it('parses vmess (base64 JSON)', () => {
    const c = parseUri('vmess://eyJ2IjoiMiIsInBzIjoibmFtZSIsImFkZCI6Im15LnNlcnZlci5jb20iLCJwb3J0IjoiNDQzIiwiaWQiOiI1NTBlODQwMC1lMjliLTQxZDQtYTcxNi00NDY2NTU0NDAwMDAiLCJhaWQiOiIwIiwibmV0Ijoid3MiLCJ0eXBlIjoibm9uZSIsImhvc3QiOiJteS5ob3N0Lm5ldCIsInBhdGgiOiIvdm1lc3MifQ==');
    expect(c.protocol).toBe('vmess');
    expect(c.server).toBe('my.server.com');
    expect(c.port).toBe(443);
    expect(c.uuid).toBe('550e8400-e29b-41d4-a716-446655440000');
    expect(c.network).toBe('ws');
    expect(c.host).toBe('my.host.net');
  });

  it('parses trojan', () => {
    const c = parseUri('trojan://password123@server.org:8443?security=tls&sni=server.org');
    expect(c.protocol).toBe('trojan');
    expect(c.password).toBe('password123');
  });

  it('parses ss (SIP002)', () => {
    const c = parseUri('ss://bWV0aG9kOnBhc3M=@ssserver.com:8388#label');
    expect(c.protocol).toBe('ss');
    expect(c.method).toBe('method');
    expect(c.password).toBe('pass');
    expect(c.server).toBe('ssserver.com');
  });

  it('throws on malformed vless', () => {
    expect(() => parseUri('vless://no-at-sign.example.com')).toThrow();
  });
});

describe('normalizer', () => {
  it('lowercases hostnames', () => {
    expect(normalizeHost('Example.COM')).toBe('example.com');
  });

  it('produces identical canonical forms for case differences', () => {
    const a = canonicalize({ protocol: 'vless', server: 'Example.COM', port: 443, uuid: 'u' });
    const b = canonicalize({ protocol: 'vless', server: 'example.com', port: 443, uuid: 'u' });
    expect(a).toBe(b);
  });

  it('canonicalizes IPv6', () => {
    expect(normalizeIpv6('2001:0DB8:0:0:0:0:0:1')).toBe(normalizeIpv6('2001:db8::1'));
  });
});

describe('validator', () => {
  it('accepts valid vless', () => {
    expect(validateConfig({ protocol: 'vless', server: 'h.com', port: 443, uuid: '550e8400-e29b-41d4-a716-446655440000' }).valid).toBe(true);
  });
  it('rejects invalid uuid', () => {
    expect(validateConfig({ protocol: 'vless', server: 'h.com', uuid: 'bad-uuid' }).valid).toBe(false);
  });
  it('rejects unsupported protocol', () => {
    expect(validateConfig({ protocol: 'wireguard', server: 'h.com' }).valid).toBe(false);
  });
  it('rejects empty server', () => {
    expect(validateConfig({ protocol: 'vless', server: '', uuid: '550e8400-e29b-41d4-a716-446655440000' }).valid).toBe(false);
  });
});

describe('fingerprint + dedup', () => {
  it('is deterministic and classifies duplicates', async () => {
    const a = { protocol: 'vless', server: 'x.com', port: 443, uuid: '550e8400-e29b-41d4-a716-446655440000' };
    const h1 = await fingerprint(a);
    const h2 = await fingerprint({ ...a });
    expect(h1).toBe(h2);

    expect(dedupClassify({ hash: h1, server: 'x.com', port: 443 }, { hash: h2, server: 'x.com', port: 443 })).toBe('exact');
    expect(dedupClassify({ hash: h1, server: 'x.com', port: 443 }, { hash: 'zzz', server: 'x.com', port: 443 })).toBe('same-endpoint');
    expect(dedupClassify({ hash: h1, server: 'x.com', port: 443 }, { hash: 'zzz', server: 'y.com', port: 443 })).toBe('different');
  });
});

describe('formatter', () => {
  it('maps country codes to flags', () => {
    expect(countryFlag('fr')).toBe('🇫🇷');
    expect(countryFlag('de')).toBe('🇩🇪');
    expect(countryFlag('xx')).toBe('🌐');
  });
  it('escapes HTML and MarkdownV2', () => {
    expect(escapeHtml('<b>&amp;</b>')).toBe('&lt;b&gt;&amp;amp;&lt;/b&gt;');
    expect(escapeMarkdownV2('*bold*_x`')).toBe('\\*bold\\*\\_x\\`');
  });
  it('builds a post with flag + code + source url', () => {
    const post = buildPostPlain('vless://x', 'fr', 'https://t.me/ch/123');
    expect(post).toContain('🇫🇷 fr');
    expect(post).toContain('https://t.me/ch/123');
  });
});

describe('NPV decoder', () => {
  it('decodes an unlocked JSON export', () => {
    const json = JSON.stringify({ tunnel: { protocol: 'vless', uuid: '550e8400-e29b-41d4-a716-446655440000', address: 'vps.example.com', port: 443, network: 'ws', tls: 'tls', sni: 'vps.example.com' } });
    const res = decodeNpv(new TextEncoder().encode(json), 'config.npv');
    expect(res.variant).toBe('unlocked-json');
    expect(res.config?.protocol).toBe('vless');
    expect(res.config?.server).toBe('vps.example.com');
  });

  it('refuses an encrypted export cleanly (no crash, no fake config)', () => {
    const sig = Uint8Array.from([0xde, 0x91, 0xce, 0x92, 0xd2, 0xd3, 0xd5, 0xe6, 0, 1, 2]);
    const res = decodeNpv(sig, 'encrypted.npv');
    expect(res.variant).toBe('encrypted-npvt1');
    expect(res.reason).toBeTruthy();
    expect(res.config).toBeUndefined();
  });

  it('handles unknown binary without crashing', () => {
    const junk = Uint8Array.from([1, 2, 3, 4]);
    const res = decodeNpv(junk, 'x.npv');
    expect(res.config).toBeUndefined();
  });
});

describe('geo ip conversion', () => {
  it('converts IPv4 and IPv6 to bigint', () => {
    expect(ipv4ToBigInt('1.2.3.4')).toBe(16909060n);
    expect(ipv4ToBigInt('255.255.255.255')).toBe(4294967295n);
    expect(ipv6ToBigInt('::1')).toBe(1n);
    expect(ipToBigInt('1.2.3.4')).toBe(16909060n);
  });
});

describe('reserved IP classification', () => {
  it('classifies private and reserved ranges', () => {
    expect(isReservedOrPrivate('10.0.0.1')).toBe(true);
    expect(isReservedOrPrivate('192.168.1.1')).toBe(true);
    expect(isReservedOrPrivate('127.0.0.1')).toBe(true);
    expect(isReservedOrPrivate('8.8.8.8')).toBe(false);
    expect(isReservedOrPrivate('::1')).toBe(true);
    expect(isReservedOrPrivate('fe80::1')).toBe(true);
  });
});

describe('queue strategies', () => {
  it('orders chronologically ascending and newest-first descending', () => {
    const base = { configIndex: 0, country: 'fr', sourceChannel: '@a', sourcePriority: 0 };
    expect(computeSortKey({ ...base, strategy: 'chronological', timestamp: 1000 })).toBeLessThan(
      computeSortKey({ ...base, strategy: 'chronological', timestamp: 2000 }),
    );
    expect(computeSortKey({ ...base, strategy: 'newest-first', timestamp: 1000 })).toBeGreaterThan(
      computeSortKey({ ...base, strategy: 'newest-first', timestamp: 2000 }),
    );
  });
});
